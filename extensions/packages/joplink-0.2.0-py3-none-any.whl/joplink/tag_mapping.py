from __future__ import annotations

from typing import Optional

from .low_level.search_service import SearchService


class TagMapping:
    """Maps tag names to tag IDs using search functionality."""

    def __init__(self, search_service: SearchService) -> None:
        """Initialize TagMapping with search service dependency.

        Args:
            search_service: Service for search operations.
        """
        self._search_service = search_service

    def map(self, tag_name: str) -> Optional[str]:
        """Map a tag name to its ID.

        Args:
            tag_name: The name of the tag to resolve.

        Returns:
            The tag ID if found, None otherwise.
        """
        # Search for tags with the title
        results = self._search_service.search(
            query=tag_name,
            search_type="tag",
            fields=["id", "title"]
        )

        # Look for an exact match
        for tag in results.items:
            if tag.title == tag_name:
                return tag.id

        return None