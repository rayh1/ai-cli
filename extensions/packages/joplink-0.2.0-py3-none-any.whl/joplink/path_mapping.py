from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date
from enum import Enum
from typing import Callable, Dict, List, Optional

from .low_level.folders_service import FoldersService
from .low_level.notes_service import NotesService
from .models import JoplinFolder, JoplinNote


# Pattern for special path macros: @name or @name:arg
_MACRO_PATTERN = re.compile(r"^@([a-zA-Z_][a-zA-Z0-9_]*)(?::(.*))?$")

# Pattern for valid macro names (used for validation)
MACRO_NAME_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")


class _ResolveStatus(Enum):
    """Internal status for resolution results."""
    RESOLVED = "resolved"
    NOT_FOUND = "not_found"
    AMBIGUOUS = "ambiguous"


@dataclass
class _FolderResolution:
    """Internal result structure for folder path resolution."""
    status: _ResolveStatus
    folder_id: Optional[str] = None


@dataclass
class _NoteResolution:
    """Internal result structure for note resolution."""
    status: _ResolveStatus
    note_id: Optional[str] = None


class PathMapping:
    """Resolves human-readable Joplin paths to folder or note IDs, and vice versa.
    
    Accepts paths like "x/y/z" and resolves them against the Joplin
    folder hierarchy and notes, returning the appropriate ID or None
    if resolution fails.
    
    Also supports reverse mapping: given an ID, returns the full path.
    
    User-defined path macros:
        All macros must be configured via user_macros parameter. There are no
        built-in macros. Macros support strftime-style placeholders (%Y, %m, %d,
        %V, %j, etc.) for date-based paths.
        
        Example: user_macros={"journal": "Journal/%Y/%m/%Y-%m-%d"} allows using
        @journal to refer to Journal/2025/12/2025-12-08 (if configured).
    """

    def __init__(
        self,
        folders_service: FoldersService,
        notes_service: NotesService,
        *,
        page_limit: int = 100,
        date_provider: Optional[Callable[[], date]] = None,
        user_macros: Optional[Dict[str, str]] = None,
    ) -> None:
        """Initialize PathMapping with service dependencies.
        
        Args:
            folders_service: Service for folder operations.
            notes_service: Service for note operations.
            page_limit: Number of items per page when paginating (default: 100).
            date_provider: Optional callable returning current date (for testing).
            user_macros: Optional dictionary mapping macro names (without '@') to
                path templates with strftime-style placeholders. Example:
                {"worklog": "Work/Logs/%Y/%m/%Y-%m-%d"}.
                
        Raises:
            ValueError: If user_macros contains invalid macro names or empty templates.
        """
        self._folders_service = folders_service
        self._notes_service = notes_service
        self._page_limit = page_limit
        self._date_provider = date_provider or date.today
        
        # Validate and store user-defined macros
        self._user_macros: Dict[str, str] = {}
        if user_macros:
            for name, template in user_macros.items():
                # Validate macro name
                if not MACRO_NAME_PATTERN.match(name):
                    raise ValueError(
                        f"Invalid macro name '{name}': must match [a-zA-Z_][a-zA-Z0-9_]*"
                    )
                # Validate template is non-empty
                if not template or not template.strip():
                    raise ValueError(
                        f"Invalid template for macro '{name}': must be non-empty string"
                    )
                # Store with normalized (lowercase) key for case-insensitive lookup
                self._user_macros[name.lower()] = template
        
        # Lazy-loaded folder cache
        self._folders_loaded = False
        self._folders_by_id: Dict[str, JoplinFolder] = {}
        self._children_by_parent: Dict[Optional[str], List[JoplinFolder]] = {}
        
        # Lazy-loaded notes cache (for mapId)
        self._notes_loaded = False
        self._notes_by_id: Dict[str, JoplinNote] = {}

    def _ensure_folders_loaded(self) -> None:
        """Load all folders and build indices if not already loaded."""
        if self._folders_loaded:
            return
        
        page = 1
        all_folders: List[JoplinFolder] = []
        
        while True:
            result = self._folders_service.list_folders(page=page, limit=self._page_limit)
            all_folders.extend(result.items)
            if not result.has_more:
                break
            page += 1
        
        # Build indices
        self._folders_by_id = {folder.id: folder for folder in all_folders}
        self._children_by_parent = {}
        
        for folder in all_folders:
            # Joplin returns '' for root folders, normalize to None
            parent_id = folder.parent_id if folder.parent_id else None
            if parent_id not in self._children_by_parent:
                self._children_by_parent[parent_id] = []
            self._children_by_parent[parent_id].append(folder)
        
        self._folders_loaded = True

    def _ensure_notes_loaded(self) -> None:
        """Load all notes and build index if not already loaded."""
        if self._notes_loaded:
            return
        
        # Ensure folders are loaded first (needed for iterating folders)
        self._ensure_folders_loaded()
        
        all_notes: List[JoplinNote] = []
        
        # Iterate through all folders and collect their notes
        for folder_id in self._folders_by_id:
            page = 1
            while True:
                result = self._folders_service.list_notes_in_folder(
                    folder_id=folder_id,
                    page=page,
                    limit=self._page_limit,
                )
                all_notes.extend(result.items)
                if not result.has_more:
                    break
                page += 1
        
        # Build index
        self._notes_by_id = {note.id: note for note in all_notes}
        self._notes_loaded = True

    def _parse_escaped_path(self, path: str) -> Optional[List[str]]:
        """Parse an escaped path into segments, handling backslash escapes.
        
        Escaping rules:
        - \\ followed by / becomes /
        - \\ followed by \\ becomes \\
        - \\ followed by anything else is invalid
        - / separates segments
        
        Args:
            path: The escaped path string to parse.
            
        Returns:
            List of decoded segments, or None if invalid escape sequences found.
        """
        # Normalize: strip whitespace and collapse multiple consecutive /
        normalized = path.strip().strip("/")
        while "//" in normalized:
            normalized = normalized.replace("//", "/")
        
        if not normalized:
            return []
        
        segments: List[str] = []
        current = ""
        i = 0
        
        while i < len(normalized):
            char = normalized[i]
            if char == "/":
                # Terminate current segment
                if current:
                    segments.append(current)
                    current = ""
            elif char == "\\":
                # Escape sequence
                if i + 1 >= len(normalized):
                    # Trailing backslash is invalid
                    return None
                next_char = normalized[i + 1]
                if next_char == "/":
                    current += "/"
                    i += 1  # Skip the escaped /
                elif next_char == "\\":
                    current += "\\"
                    i += 1  # Skip the escaped \
                else:
                    # Invalid escape
                    return None
            else:
                current += char
            i += 1
        
        # Append final segment if any
        if current:
            segments.append(current)
        
        # Filter out empty segments (though normalization should prevent this)
        segments = [seg for seg in segments if seg]
        
        return segments

    @staticmethod
    def encode_segments(segments: List[str]) -> str:
        """Encode segments into an escaped path string.
        
        Encoding rules:
        - / becomes \\/
        - \\ becomes \\\\
        - Other characters unchanged
        
        Args:
            segments: List of segment strings to encode.
            
        Returns:
            The encoded path string.
        """
        def encode_segment(segment: str) -> str:
            # Replace \ first, then /
            return segment.replace("\\", "\\\\").replace("/", "\\/")
        
        return "/".join(encode_segment(seg) for seg in segments)

    def _expand_user_macro(self, name: str, template: str, arg: Optional[str]) -> str:
        """Expand a user-defined macro using strftime-style placeholders.
        
        Args:
            name: The macro name (for error messages).
            template: The path template with strftime placeholders.
            arg: Optional argument (must be None for user macros).
            
        Returns:
            The expanded path with placeholders replaced.
            
        Raises:
            ValueError: If arg is not None (user macros don't accept arguments).
        """
        if arg is not None:
            raise ValueError(f"@{name} does not accept an argument")
        
        # Get current date and expand template using strftime
        current_date = self._date_provider()
        expanded = current_date.strftime(template)
        return expanded

    def _expand_special_path(self, path: str) -> str:
        """Expand special path macros into concrete paths.
        
        Only user-defined macros are supported. All macros must be configured
        via user_macros parameter in __init__.
        
        User macros:
            Defined via user_macros parameter in __init__. Support strftime
            placeholders like %Y, %m, %d, %V, %j, etc.
        
        Args:
            path: The path string, possibly containing a macro.
            
        Returns:
            The expanded path, or the original path if no macro matched.
            
        Raises:
            ValueError: If the macro is recognized but an argument is provided
                (user macros don't accept arguments).
        """
        stripped = path.strip()
        
        # Check if path starts with a macro (@name or @name:arg), possibly followed by /path
        # Split on first / to separate macro from rest of path
        if stripped.startswith('@'):
            # Find the first / that's not escaped
            first_slash = stripped.find('/')
            if first_slash == -1:
                # No slash, entire thing might be a macro
                macro_part = stripped
                rest_of_path = ""
            else:
                macro_part = stripped[:first_slash]
                rest_of_path = stripped[first_slash:]  # includes the /
            
            # Try to match the macro part
            match = _MACRO_PATTERN.match(macro_part)
            if match:
                macro_name = match.group(1).lower()
                macro_arg = match.group(2)  # May be None
                
                # Check user-defined macros
                if macro_name in self._user_macros:
                    template = self._user_macros[macro_name]
                    expanded_macro = self._expand_user_macro(macro_name, template, macro_arg)
                    
                    # Combine with rest of path
                    if rest_of_path:
                        # Remove leading / from rest_of_path and join
                        return expanded_macro + rest_of_path
                    else:
                        return expanded_macro
        
        # Unknown macro or not a macro - return unchanged
        return path

    def _resolve_folder_path(self, segments: List[str]) -> _FolderResolution:
        """Resolve a path through the folder hierarchy.
        
        Args:
            segments: Path segments to traverse.
            
        Returns:
            _FolderResolution with status and optional folder_id.
        """
        self._ensure_folders_loaded()
        
        current_parent_id: Optional[str] = None
        for segment in segments:
            candidates = self._children_by_parent.get(current_parent_id, [])
            matches = [f for f in candidates if f.title == segment]
            
            if not matches:
                return _FolderResolution(_ResolveStatus.NOT_FOUND)
            if len(matches) > 1:
                return _FolderResolution(_ResolveStatus.AMBIGUOUS)
            
            current_parent_id = matches[0].id
        
        if current_parent_id is None:
            return _FolderResolution(_ResolveStatus.NOT_FOUND)
        
        return _FolderResolution(_ResolveStatus.RESOLVED, folder_id=current_parent_id)

    def _resolve_note_in_folder(self, parent_folder_id: str, title: str) -> _NoteResolution:
        """Resolve a note by title within a specific folder.
        
        Args:
            parent_folder_id: ID of the folder containing the note.
            title: Title of the note to find.
            
        Returns:
            _NoteResolution with status and optional note_id.
        """
        page = 1
        matches: List[JoplinNote] = []
        
        while True:
            page_result = self._folders_service.list_notes_in_folder(
                folder_id=parent_folder_id,
                page=page,
                limit=self._page_limit,
            )
            for note in page_result.items:
                if note.title == title:
                    matches.append(note)
            
            if not page_result.has_more:
                break
            page += 1
        
        if not matches:
            return _NoteResolution(_ResolveStatus.NOT_FOUND)
        if len(matches) > 1:
            return _NoteResolution(_ResolveStatus.AMBIGUOUS)
        
        return _NoteResolution(_ResolveStatus.RESOLVED, note_id=matches[0].id)

    def mapPath(self, path: str, kind: str = "auto") -> Optional[str]:
        """Resolve a path to a folder or note ID.
        
        Args:
            path: Absolute path like "x/y/z" (no leading slash required),
                  or a user-defined macro like "@journal" (if configured in user_macros).
            kind: One of "folder", "note", or "auto" (default: "auto").
            
        Returns:
            The resolved ID as a string, or None if resolution fails
            (not found or ambiguous).
            
        Raises:
            ValueError: If kind is not one of the valid values, or if
                        a macro argument is invalid.
        """
        # Validate and normalize kind
        kind_lower = kind.lower()
        if kind_lower not in ("folder", "note", "auto"):
            raise ValueError(f"Invalid kind: {kind}. Must be 'folder', 'note', or 'auto'.")
        
        # Expand user-defined path macros (e.g. @journal -> Journal/2025/12/2025-12-05 if configured)
        expanded_path = self._expand_special_path(path)
        
        # Parse escaped path into segments
        segments = self._parse_escaped_path(expanded_path)
        if segments is None or not segments:
            return None
        
        # Branch based on kind
        if kind_lower == "folder":
            return self._map_folder(segments)
        elif kind_lower == "note":
            return self._map_note(segments)
        else:  # auto
            return self._map_auto(segments)

    def _map_folder(self, segments: List[str]) -> Optional[str]:
        """Resolve path as folders only."""
        result = self._resolve_folder_path(segments)
        if result.status == _ResolveStatus.RESOLVED:
            return result.folder_id
        return None

    def _map_note(self, segments: List[str]) -> Optional[str]:
        """Resolve path as folders + terminal note.
        
        Requires at least 2 segments (folder path + note title).
        """
        if len(segments) < 2:
            return None
        
        folder_segments = segments[:-1]
        note_title = segments[-1]
        
        folder_result = self._resolve_folder_path(folder_segments)
        if folder_result.status != _ResolveStatus.RESOLVED or folder_result.folder_id is None:
            return None
        
        note_result = self._resolve_note_in_folder(folder_result.folder_id, note_title)
        if note_result.status == _ResolveStatus.RESOLVED:
            return note_result.note_id
        
        return None

    def _map_auto(self, segments: List[str]) -> Optional[str]:
        """Resolve path with auto detection (prefer note, fallback to folder)."""
        # Single segment: resolve as folder only (no global note search)
        if len(segments) == 1:
            return self._map_folder(segments)
        
        # Multi-segment: try parent folder first
        folder_segments = segments[:-1]
        note_title = segments[-1]
        
        parent_result = self._resolve_folder_path(folder_segments)
        
        if parent_result.status == _ResolveStatus.RESOLVED and parent_result.folder_id is not None:
            # Parent folder exists, try resolving as note
            note_result = self._resolve_note_in_folder(parent_result.folder_id, note_title)
            
            if note_result.status == _ResolveStatus.RESOLVED:
                # Found matching note, prefer it
                return note_result.note_id
            
            # Note not found or ambiguous, fall back to full folder path
            folder_result = self._resolve_folder_path(segments)
            if folder_result.status == _ResolveStatus.RESOLVED:
                return folder_result.folder_id
            
            return None
        else:
            # Parent folder doesn't exist or is ambiguous, try full folder path
            folder_result = self._resolve_folder_path(segments)
            if folder_result.status == _ResolveStatus.RESOLVED:
                return folder_result.folder_id
            
            return None

    def _build_folder_path(self, folder_id: str) -> Optional[List[str]]:
        """Build path segments from root to the given folder.
        
        Args:
            folder_id: ID of the folder.
            
        Returns:
            List of folder titles from root to the folder, or None if not found.
        """
        self._ensure_folders_loaded()
        
        segments: List[str] = []
        current_id: Optional[str] = folder_id
        
        while current_id is not None:
            folder = self._folders_by_id.get(current_id)
            if folder is None:
                return None
            
            title = folder.title if folder.title else ""
            segments.append(title)
            
            # Move to parent (normalize empty string to None)
            current_id = folder.parent_id if folder.parent_id else None
        
        # Reverse to get root-to-leaf order
        segments.reverse()
        return segments

    def mapId(self, item_id: str, kind: str = "auto") -> Optional[str]:
        """Resolve an ID to a full path.
        
        Args:
            item_id: The ID of a note or folder.
            kind: One of "folder", "note", or "auto" (default: "auto").
                  - "folder": Treat the ID as a folder ID.
                  - "note": Treat the ID as a note ID.
                  - "auto": Try note first, then folder.
            
        Returns:
            The encoded path string (with escaped slashes/backslashes),
            or None if the ID is not found.
            
        Raises:
            ValueError: If kind is not one of the valid values.
        """
        # Validate and normalize kind
        kind_lower = kind.lower()
        if kind_lower not in ("folder", "note", "auto"):
            raise ValueError(f"Invalid kind: {kind}. Must be 'folder', 'note', or 'auto'.")
        
        if kind_lower == "folder":
            return self._map_id_as_folder(item_id)
        elif kind_lower == "note":
            return self._map_id_as_note(item_id)
        else:  # auto
            # Try note first, then folder
            result = self._map_id_as_note(item_id)
            if result is not None:
                return result
            return self._map_id_as_folder(item_id)

    def _map_id_as_folder(self, folder_id: str) -> Optional[str]:
        """Map a folder ID to its path."""
        segments = self._build_folder_path(folder_id)
        if segments is None:
            return None
        return self.encode_segments(segments)

    def _map_id_as_note(self, note_id: str) -> Optional[str]:
        """Map a note ID to its path."""
        self._ensure_notes_loaded()
        
        note = self._notes_by_id.get(note_id)
        if note is None:
            return None
        
        # Get parent folder path
        parent_id = note.parent_id if note.parent_id else None
        if parent_id is None:
            # Note has no parent folder - this shouldn't happen in Joplin
            # but handle it gracefully
            return None
        
        folder_segments = self._build_folder_path(parent_id)
        if folder_segments is None:
            return None
        
        # Append note title
        note_title = note.title if note.title else ""
        segments = folder_segments + [note_title]
        
        return self.encode_segments(segments)
