from __future__ import annotations

from typing import Any, Dict, List, Optional, Union, Generic, TypeVar

from pydantic import BaseModel, Field


# Pagination defaults per Joplin Data API documentation
DEFAULT_PAGE: int = 1
"""Default page number for paginated API requests (1-indexed)."""

DEFAULT_LIMIT: int = 10
"""Default number of items per page for paginated API requests."""


class JoplinNote(BaseModel):
    """Represents a Joplin note as returned by the Data API.

    Only fields relevant to the project are included; additional
    keys returned by the server are ignored by the model.
    """
    id: str
    parent_id: Optional[str] = None
    title: Optional[str] = None
    body: Optional[str] = None
    created_time: Optional[int] = None
    updated_time: Optional[int] = None
    is_conflict: Optional[int] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    altitude: Optional[float] = None
    author: Optional[str] = None
    is_todo: Optional[int] = None
    todo_due: Optional[int] = None
    todo_completed: Optional[int] = None
    source: Optional[str] = None
    source_application: Optional[str] = None
    user_created_time: Optional[int] = None
    user_updated_time: Optional[int] = None
    deleted_time: Optional[int] = None
    body_html: Optional[str] = None
    base_url: Optional[str] = None


class JoplinFolder(BaseModel):
    """Represents a Joplin folder (notebook) returned by the API."""
    id: str
    title: Optional[str] = None
    created_time: Optional[int] = None
    updated_time: Optional[int] = None
    parent_id: Optional[str] = None
    deleted_time: Optional[int] = None


class JoplinTag(BaseModel):
    """Represents a Joplin tag resource returned by the API."""
    id: str
    title: Optional[str] = None
    created_time: Optional[int] = None
    updated_time: Optional[int] = None
    deleted_time: Optional[int] = None


T = TypeVar("T")


class PagedResults(BaseModel, Generic[T]):
    """Generic structure for paginated responses.

    Use `PagedResults[MyModel]` where `MyModel` is a Pydantic model or a
    typing hint such as `Dict[str, Any]`.

    Attributes:
        items: List of items in the current page.
        has_more: True if there are more pages available after this one.
        page: The 1-indexed page number of the current results.
        limit: The maximum number of items requested per page.
    """
    items: List[T]
    has_more: bool
    page: int = Field(default=DEFAULT_PAGE, description="1-indexed page number of the current results")
    limit: int = Field(default=DEFAULT_LIMIT, description="Maximum number of items per page")


def paged_results_to_dict(results: PagedResults[T]) -> Dict[str, Any]:
    """Convert a PagedResults instance to a JSON-serializable dict.

    This helper normalizes the structure used at the MCP boundary so that
    all paginated tools share the same response shape.
    """
    return {
        "items": [
            item.model_dump(exclude_none=True)
            if isinstance(item, BaseModel)
            else item
            for item in results.items
        ],
        "has_more": results.has_more,
        "page": results.page,
        "limit": results.limit,
    }
