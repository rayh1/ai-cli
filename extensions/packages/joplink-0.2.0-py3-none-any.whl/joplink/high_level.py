"""High-level Joplin client providing path-aware operations.

This module provides `HighLevelJoplinClient`, a facade that builds on top of
the low-level services to provide a more ergonomic API with human-readable
path support, search-aware listing, and common utility operations.
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional

from .low_level.base import JoplinClientError, JoplinNotFoundError, JoplinPathError
from .low_level.client import JoplinClient
from .models import JoplinFolder, JoplinNote, JoplinTag, PagedResults
from .path_mapping import PathMapping
from .tag_mapping import TagMapping


# Pattern to detect Joplin IDs: 32-character lowercase hexadecimal
_ID_PATTERN = re.compile(r"^[0-9a-f]{32}$")


def _is_id(value: str) -> bool:
    """Check if a value looks like a Joplin ID (32-char lowercase hex)."""
    return bool(_ID_PATTERN.match(value))


class HighLevelJoplinClient:
    """High-level Joplin client with path-aware operations.
    
    This class provides a more ergonomic API that works with human-readable
    paths, optional search queries, and common operations like "append to note"
    and "move note between folders".
    
    Example:
        from joplink import JoplinClient
        from joplink.high_level import HighLevelJoplinClient
        
        low = JoplinClient()
        hl = HighLevelJoplinClient(low)
        
        # Get note by path
        note = hl.get_note("Projects/MyNote")
        
        # Append content to a note
        hl.append_to_note("Projects/MyNote", "New content here")
    """

    def __init__(self, client: JoplinClient, path_mapping: Optional[PathMapping] = None) -> None:
        """Initialize the high-level client.
        
        Args:
            client: An existing low-level JoplinClient instance.
            path_mapping: Optional pre-configured PathMapping instance. If None,
                a default PathMapping will be created with no user macros.
        """
        self._client = client
        self._notes = client.notes
        self._folders = client.folders
        self._tags = client.tags
        self._search = client.search
        self._path_mapping = path_mapping or PathMapping(client.folders, client.notes)
        # Store user_macros so we can recreate PathMapping with same config
        self._user_macros = self._path_mapping._user_macros if path_mapping else None
        self._tag_mapping = TagMapping(client.search)

    # -------------------------------------------------------------------------
    # Internal resolution helpers
    # -------------------------------------------------------------------------

    def _resolve_note_id(self, note_ref: str) -> str:
        """Resolve a note reference (id or path) to a note ID.
        
        Args:
            note_ref: Joplin note id or absolute path like "folder/note".
            
        Returns:
            The resolved note ID.
            
        Raises:
            JoplinNotFoundError: If the note cannot be found.
        """
        if _is_id(note_ref):
            return note_ref
        
        note_id = self._path_mapping.mapPath(note_ref, kind="note")
        if note_id is None:
            raise JoplinNotFoundError(f"Note not found: {note_ref}")
        return note_id

    def _resolve_folder_id(self, folder_ref: str) -> str:
        """Resolve a folder reference (id or path) to a folder ID.
        
        Args:
            folder_ref: Joplin folder id or absolute path like "parent/child".
            
        Returns:
            The resolved folder ID.
            
        Raises:
            JoplinNotFoundError: If the folder cannot be found.
        """
        if _is_id(folder_ref):
            return folder_ref
        
        folder_id = self._path_mapping.mapPath(folder_ref, kind="folder")
        if folder_id is None:
            raise JoplinNotFoundError(f"Folder not found: {folder_ref}")
        return folder_id

    def _resolve_tag_id(self, tag_ref: str) -> str:
        """Resolve a tag reference (id or title) to a tag ID.
        
        Args:
            tag_ref: Joplin tag id or tag title.
            
        Returns:
            The resolved tag ID.
            
        Raises:
            JoplinNotFoundError: If the tag cannot be found.
            JoplinClientError: If multiple tags share the same title.
        """
        if _is_id(tag_ref):
            return tag_ref
        
        # Use TagMapping to resolve tag by title
        tag_id = self._tag_mapping.map(tag_ref)
        if tag_id is None:
            raise JoplinNotFoundError(f"Tag not found: {tag_ref}")
        
        return tag_id

    def _split_path(self, path: str) -> tuple[str, str]:
        """Split a path into parent folder path and final segment (title).
        
        Args:
            path: A path like "parent/child/item".
            
        Returns:
            Tuple of (parent_path, title). For "a/b/c", returns ("a/b", "c").
            For "item" with no slash, returns ("", "item").
            The returned values preserve escape sequences.
            
        Raises:
            JoplinPathError: If the path contains invalid escape sequences.
        """
        # Use PathMapping's escape-aware parsing
        segments = PathMapping._parse_escaped_path(self._path_mapping, path)
        
        if segments is None:
            raise JoplinPathError(
                f"Invalid path '{path}': contains invalid escape sequences. "
                "Use \\/ to escape a slash and \\\\ to escape a backslash."
            )
        
        if len(segments) == 0:
            return ("", path)
        
        if len(segments) == 1:
            # Re-encode to preserve escape sequences
            return ("", PathMapping.encode_segments(segments))
        
        # Re-encode parent segments and title back to escaped path format
        parent_path = PathMapping.encode_segments(segments[:-1])
        title = PathMapping.encode_segments([segments[-1]])
        return (parent_path, title)

    def _invalidate_path_cache(self) -> None:
        """Invalidate the path mapping cache to reflect changes."""
        # Reset the path mapping to force reload on next access
        # Preserve user_macros from the original PathMapping
        self._path_mapping = PathMapping(
            self._folders,
            self._notes,
            user_macros=self._user_macros,
        )

    def _ensure_id_in_fields(self, fields: Optional[Iterable[str]]) -> Optional[list[str]]:
        """Ensure 'id' is included in fields list.
        
        Typed models (JoplinNote, JoplinFolder, JoplinTag) require 'id' to be present.
        When callers provide a fields list, this helper ensures 'id' is always included
        to prevent Pydantic validation failures.
        
        Args:
            fields: Optional iterable of field names.
            
        Returns:
            None if fields is None (preserves API defaults),
            otherwise a list containing all fields plus 'id' if not already present.
        """
        if fields is None:
            return None
        
        # Materialize to list and ensure id is present
        fields_list = list(fields)
        if "id" not in fields_list:
            fields_list.append("id")
        return fields_list

    # -------------------------------------------------------------------------
    # Note CRUD operations
    # -------------------------------------------------------------------------

    def get_note(self, note_ref: str, *, fields: Optional[Iterable[str]] = None) -> JoplinNote:
        """Get a note by ID or path.
        
        Args:
            note_ref: Joplin note id or absolute path like "folder/note".
            fields: Optional fields to include in the response.
                If fields is provided, 'id' is always included in the request
                (even if omitted) since typed models require it.
            
        Returns:
            The requested JoplinNote.
            
        Raises:
            JoplinNotFoundError: If the note cannot be found.
        """
        note_id = self._resolve_note_id(note_ref)
        effective_fields = self._ensure_id_in_fields(fields)
        return self._notes.get_note(note_id, fields=effective_fields)

    def save_note(self, note_ref: str, **fields: Any) -> JoplinNote:
        """Create or update a note.
        
        If the note exists (id or path resolves), it is updated.
        If the note does not exist and note_ref is a path, a new note is created.
        
        Args:
            note_ref: Joplin note id or absolute path like "folder/note_title".
            **fields: Note fields to set (body, etc.). When creating a new note,
                the 'title' and 'parent_id' fields are determined by the path
                and cannot be overridden via this parameter.
            
        Returns:
            The created or updated JoplinNote.
            
        Raises:
            JoplinNotFoundError: If the parent folder for a new note cannot be found.
            JoplinPathError: If the path contains invalid escape sequences.
        """
        # Try to resolve as existing note
        if _is_id(note_ref):
            # It's an ID - try to get the note
            try:
                self._notes.get_note(note_ref)
                # Note exists, update it
                return self._notes.update_note(note_ref, fields)
            except JoplinNotFoundError:
                raise JoplinNotFoundError(f"Note not found: {note_ref}")
        
        # Expand any path macros (e.g., @journal -> Journal/2025/12/2025-12-08 if configured)
        expanded_path = self._path_mapping._expand_special_path(note_ref)
        
        # It's a path - try to resolve it
        note_id = self._path_mapping.mapPath(expanded_path, kind="note")
        if note_id is not None:
            # Note exists, update it
            return self._notes.update_note(note_id, fields)
        
        # Note doesn't exist - create it
        # Split path into parent folder path and note title
        parent_path, title = self._split_path(expanded_path)
        
        if not parent_path:
            # Show expanded path in error message for clarity
            path_display = expanded_path if expanded_path != note_ref else note_ref
            raise JoplinNotFoundError(
                f"Cannot create note '{path_display}': note path must include a parent folder"
            )
        
        # Resolve parent folder
        parent_id = self._path_mapping.mapPath(parent_path, kind="folder")
        if parent_id is None:
            raise JoplinNotFoundError(f"Parent folder not found: {parent_path}")
        
        # Create the note - strip protected keys that are determined by the path
        filtered_fields = {k: v for k, v in fields.items() if k not in ("title", "parent_id")}
        data: Dict[str, Any] = {"title": title, "parent_id": parent_id}
        data.update(filtered_fields)
        note = self._notes.create_note(data)
        self._invalidate_path_cache()
        return note

    def delete_note(self, note_ref: str) -> None:
        """Delete a note by ID or path.
        
        Args:
            note_ref: Joplin note id or absolute path like "folder/note".
            
        Raises:
            JoplinNotFoundError: If the note cannot be found.
        """
        note_id = self._resolve_note_id(note_ref)
        self._notes.delete_note(note_id)
        self._invalidate_path_cache()

    # -------------------------------------------------------------------------
    # Folder CRUD operations
    # -------------------------------------------------------------------------

    def create_folder(self, path: str, **fields: Any) -> JoplinFolder:
        """Create a new folder at the specified path.
        
        Args:
            path: Folder path like "parent/child" or just "name" for root folder.
            **fields: Additional folder fields. The 'title' and 'parent_id' fields
                are determined by the path and cannot be overridden via this parameter.
            
        Returns:
            The created JoplinFolder.
            
        Raises:
            JoplinNotFoundError: If the parent folder cannot be found.
            JoplinPathError: If the path contains invalid escape sequences.
        """
        parent_path, title = self._split_path(path)
        
        # Strip protected keys that are determined by the path
        filtered_fields = {k: v for k, v in fields.items() if k not in ("title", "parent_id")}
        data: Dict[str, Any] = {"title": title}
        data.update(filtered_fields)
        
        if parent_path:
            # Nested folder - resolve parent
            parent_id = self._path_mapping.mapPath(parent_path, kind="folder")
            if parent_id is None:
                raise JoplinNotFoundError(f"Parent folder not found: {parent_path}")
            data["parent_id"] = parent_id
        
        folder = self._folders.create_folder(data)
        self._invalidate_path_cache()
        return folder

    def get_folder(self, folder_ref: str, *, fields: Optional[Iterable[str]] = None) -> JoplinFolder:
        """Get a folder by ID or path.
        
        Args:
            folder_ref: Joplin folder id or absolute path like "parent/child".
            fields: Optional fields to include in the response.
                If fields is provided, 'id' is always included in the request
                (even if omitted) since typed models require it.
            
        Returns:
            The requested JoplinFolder.
            
        Raises:
            JoplinNotFoundError: If the folder cannot be found.
        """
        folder_id = self._resolve_folder_id(folder_ref)
        effective_fields = self._ensure_id_in_fields(fields)
        return self._folders.get_folder(folder_id, fields=effective_fields)

    def delete_folder(self, folder_ref: str) -> None:
        """Delete a folder by ID or path.
        
        Args:
            folder_ref: Joplin folder id or absolute path like "parent/child".
            
        Raises:
            JoplinNotFoundError: If the folder cannot be found.
        """
        folder_id = self._resolve_folder_id(folder_ref)
        self._folders.delete_folder(folder_id)
        self._invalidate_path_cache()

    # -------------------------------------------------------------------------
    # Tag CRUD operations
    # -------------------------------------------------------------------------

    def save_tag(self, name: str) -> JoplinTag:
        """Get or create a tag by name.
        
        If a tag with the given name already exists, it is returned.
        Otherwise, a new tag is created.
        
        Args:
            name: The tag name/title.
            
        Returns:
            The existing or newly created JoplinTag.
        """
        # Search for existing tag with exact title
        page = 1
        while True:
            result = self._tags.list_tags(fields=["id", "title"], page=page, limit=100)
            for tag in result.items:
                if tag.title == name:
                    return tag
            if not result.has_more:
                break
            page += 1
        
        # Tag doesn't exist, create it
        return self._tags.create_tag({"title": name})

    def get_tag(self, tag_ref: str, *, fields: Optional[Iterable[str]] = None) -> JoplinTag:
        """Get a tag by ID or title.
        
        Args:
            tag_ref: Joplin tag id or tag title.
            fields: Optional fields to include in the response.
                If fields is provided, 'id' is always included in the request
                (even if omitted) since typed models require it.
            
        Returns:
            The requested JoplinTag.
            
        Raises:
            JoplinNotFoundError: If the tag cannot be found.
            JoplinClientError: If multiple tags share the same title.
        """
        tag_id = self._resolve_tag_id(tag_ref)
        effective_fields = self._ensure_id_in_fields(fields)
        return self._tags.get_tag(tag_id, fields=effective_fields)

    def delete_tag(self, tag_ref: str) -> None:
        """Delete a tag by ID or title.
        
        Args:
            tag_ref: Joplin tag id or tag title.
            
        Raises:
            JoplinNotFoundError: If the tag cannot be found.
            JoplinClientError: If multiple tags share the same title.
        """
        tag_id = self._resolve_tag_id(tag_ref)
        self._tags.delete_tag(tag_id)

    # -------------------------------------------------------------------------
    # Search-aware list methods
    # -------------------------------------------------------------------------

    def search_notes(
        self,
        query: Optional[str] = None,
        *,
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> PagedResults[JoplinNote]:
        """Search notes.
        
        Args:
            query: Optional search query. If None, lists all notes.
            fields: Optional fields to include in the response.
                If fields is provided, 'id' is always included in the request
                (even if omitted) since typed models require it.
            page: Optional page number for pagination.
            limit: Optional limit on results.
            
        Returns:
            PagedResults containing matching notes.
        """
        effective_fields = self._ensure_id_in_fields(fields)
        if query is None:
            return self._notes.list_notes(fields=effective_fields, page=page, limit=limit)
        return self._search.search(query, search_type="note", fields=effective_fields, page=page, limit=limit)

    def search_folders(
        self,
        query: Optional[str] = None,
        *,
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> PagedResults[JoplinFolder]:
        """Search folders.
        
        Args:
            query: Optional search query. If None, lists all folders.
            fields: Optional fields to include in the response.
                If fields is provided, 'id' is always included in the request
                (even if omitted) since typed models require it.
            page: Optional page number for pagination.
            limit: Optional limit on results.
            
        Returns:
            PagedResults containing matching folders.
        """
        effective_fields = self._ensure_id_in_fields(fields)
        if query is None:
            return self._folders.list_folders(fields=effective_fields, page=page, limit=limit)
        return self._search.search(query, search_type="folder", fields=effective_fields, page=page, limit=limit)

    def search_tags(
        self,
        query: Optional[str] = None,
        *,
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> PagedResults[JoplinTag]:
        """Search tags.
        
        Args:
            query: Optional search query. If None, lists all tags.
            fields: Optional fields to include in the response.
                If fields is provided, 'id' is always included in the request
                (even if omitted) since typed models require it.
            page: Optional page number for pagination.
            limit: Optional limit on results.
            
        Returns:
            PagedResults containing matching tags.
        """
        effective_fields = self._ensure_id_in_fields(fields)
        if query is None:
            return self._tags.list_tags(fields=effective_fields, page=page, limit=limit)
        return self._search.search(query, search_type="tag", fields=effective_fields, page=page, limit=limit)

    # -------------------------------------------------------------------------
    # Utility note operations
    # -------------------------------------------------------------------------

    def append_to_note(
        self,
        note_ref: str,
        content: str,
        *,
        separator: str = "\n",
    ) -> JoplinNote:
        """Append content to an existing note, or create the note if it does not exist.
        
        If the note exists, content is appended to the existing body.
        If the note does not exist and note_ref is a path, a new note is created
        with the provided content as its body.
        
        Args:
            note_ref: Joplin note id or absolute path like "folder/note_title".
            content: The content to append (or set for new notes).
            separator: Separator between existing and new content (default: newline).
                Only used when appending to existing notes.
            
        Returns:
            The updated or created JoplinNote.
            
        Raises:
            JoplinNotFoundError: If the note id does not exist, or if the parent
                folder for a new note cannot be found.
            JoplinPathError: If the path contains invalid escape sequences.
        """
        try:
            note = self.get_note(note_ref, fields=["id", "body"])
            current_body = note.body or ""
            if current_body:
                new_body = current_body + separator + content
            else:
                new_body = content
            return self.save_note(note_ref, body=new_body)
        except JoplinNotFoundError:
            return self.save_note(note_ref, body=content)

    # -------------------------------------------------------------------------
    # Moving and renaming
    # -------------------------------------------------------------------------

    def move_note(self, note_ref: str, *, to_folder_ref: str) -> JoplinNote:
        """Move a note to a different folder.
        
        Args:
            note_ref: Joplin note id or absolute path.
            to_folder_ref: Destination folder id or path.
            
        Returns:
            The updated JoplinNote.
            
        Raises:
            JoplinNotFoundError: If the note or destination folder cannot be found.
        """
        note_id = self._resolve_note_id(note_ref)
        folder_id = self._resolve_folder_id(to_folder_ref)
        note = self._notes.update_note(note_id, {"parent_id": folder_id})
        self._invalidate_path_cache()
        return note

    def rename_note(self, note_ref: str, *, new_title: str) -> JoplinNote:
        """Rename a note.
        
        Args:
            note_ref: Joplin note id or absolute path.
            new_title: The new title for the note.
            
        Returns:
            The updated JoplinNote.
            
        Raises:
            JoplinNotFoundError: If the note cannot be found.
        """
        note_id = self._resolve_note_id(note_ref)
        note = self._notes.update_note(note_id, {"title": new_title})
        self._invalidate_path_cache()
        return note

    def move_folder(self, folder_ref: str, *, to_folder_ref: Optional[str]) -> JoplinFolder:
        """Move a folder to a different parent folder.
        
        Args:
            folder_ref: Joplin folder id or absolute path.
            to_folder_ref: Destination folder id or path, or None to move to root.
            
        Returns:
            The updated JoplinFolder.
            
        Raises:
            JoplinNotFoundError: If the folder or destination folder cannot be found.
        """
        folder_id = self._resolve_folder_id(folder_ref)
        
        if to_folder_ref is None:
            new_parent_id = ""
        else:
            new_parent_id = self._resolve_folder_id(to_folder_ref)
        
        folder = self._folders.update_folder(folder_id, {"parent_id": new_parent_id})
        self._invalidate_path_cache()
        return folder

    def rename_folder(self, folder_ref: str, *, new_title: str) -> JoplinFolder:
        """Rename a folder.
        
        Args:
            folder_ref: Joplin folder id or absolute path.
            new_title: The new title for the folder.
            
        Returns:
            The updated JoplinFolder.
            
        Raises:
            JoplinNotFoundError: If the folder cannot be found.
        """
        folder_id = self._resolve_folder_id(folder_ref)
        folder = self._folders.update_folder(folder_id, {"title": new_title})
        self._invalidate_path_cache()
        return folder

    # -------------------------------------------------------------------------
    # Tagging utilities
    # -------------------------------------------------------------------------

    def tag_note(self, note_ref: str, tag_ref: str) -> None:
        """Add a tag to a note.
        
        If tag_ref is a title (not an ID), the tag is created if it doesn't exist.
        
        Args:
            note_ref: Joplin note id or absolute path.
            tag_ref: Joplin tag id or tag title.
            
        Raises:
            JoplinNotFoundError: If the note cannot be found.
        """
        note_id = self._resolve_note_id(note_ref)
        
        if _is_id(tag_ref):
            tag_id = tag_ref
        else:
            # Get or create the tag
            tag = self.save_tag(tag_ref)
            tag_id = tag.id
        
        self._tags.add_tag_to_note(tag_id, note_id)

    def untag_note(self, note_ref: str, tag_ref: str) -> None:
        """Remove a tag from a note.
        
        Args:
            note_ref: Joplin note id or absolute path.
            tag_ref: Joplin tag id or tag title.
            
        Raises:
            JoplinNotFoundError: If the note or tag cannot be found.
            JoplinClientError: If multiple tags share the same title.
        """
        note_id = self._resolve_note_id(note_ref)
        tag_id = self._resolve_tag_id(tag_ref)
        self._tags.remove_tag_from_note(tag_id, note_id)

    def list_notes_for_tag(
        self,
        tag_ref: str,
        *,
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> PagedResults[JoplinNote]:
        """List notes associated with a tag.
        
        Args:
            tag_ref: Joplin tag id or tag title.
            fields: Optional fields to include in the response.
                If fields is provided, 'id' is always included in the request
                (even if omitted) since typed models require it.
            page: Optional page number for pagination.
            limit: Optional limit on results.
            
        Returns:
            PagedResults containing notes with this tag.
            
        Raises:
            JoplinNotFoundError: If the tag cannot be found.
            JoplinClientError: If multiple tags share the same title.
        """
        tag_id = self._resolve_tag_id(tag_ref)
        effective_fields = self._ensure_id_in_fields(fields)
        return self._tags.list_notes_for_tag(tag_id, fields=effective_fields, page=page, limit=limit)

    # -------------------------------------------------------------------------
    # Path-based listing
    # -------------------------------------------------------------------------

    def list_notes_in_folder(
        self,
        folder_ref: str,
        *,
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> PagedResults[JoplinNote]:
        """List notes in a specific folder.
        
        Args:
            folder_ref: Joplin folder id or absolute path.
            fields: Optional fields to include in the response.
                If fields is provided, 'id' is always included in the request
                (even if omitted) since typed models require it.
            page: Optional page number for pagination.
            limit: Optional limit on results.
            
        Returns:
            PagedResults containing notes in the folder.
            
        Raises:
            JoplinNotFoundError: If the folder cannot be found.
        """
        folder_id = self._resolve_folder_id(folder_ref)
        effective_fields = self._ensure_id_in_fields(fields)
        return self._folders.list_notes_in_folder(folder_id, fields=effective_fields, page=page, limit=limit)

    def list_tags_for_note(
        self,
        note_ref: str,
        *,
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> PagedResults[JoplinTag]:
        """List tags associated with a note.
        
        Args:
            note_ref: Joplin note id or absolute path like "folder/note".
            fields: Optional fields to include in the response.
                If fields is provided, 'id' is always included in the request
                (even if omitted) since typed models require it.
            page: Optional page number for pagination.
            limit: Optional limit on results.
            
        Returns:
            PagedResults containing tags associated with the note.
            
        Raises:
            JoplinNotFoundError: If the note cannot be found.
        """
        note_id = self._resolve_note_id(note_ref)
        effective_fields = self._ensure_id_in_fields(fields)
        return self._notes.list_tags_for_note(note_id, fields=effective_fields, page=page, limit=limit)

    def list_child_folders(
        self,
        folder_ref: Optional[str],
        *,
        fields: Optional[Iterable[str]] = None,
    ) -> List[JoplinFolder]:
        """List child folders of a folder.
        
        Args:
            folder_ref: Joplin folder id or path, or None for root-level folders.
            fields: Optional fields to include in the response.
                If fields is provided, 'id' is always included in the request
                (even if omitted) since typed models require it.
            
        Returns:
            List of child folders.
            
        Raises:
            JoplinNotFoundError: If the folder cannot be found (when folder_ref is not None).
        """
        if folder_ref is None:
            target_parent_id = None
        else:
            target_parent_id = self._resolve_folder_id(folder_ref)
        
        effective_fields = self._ensure_id_in_fields(fields)
        
        # List all folders and filter by parent_id
        result: List[JoplinFolder] = []
        page = 1
        while True:
            page_result = self._folders.list_folders(fields=effective_fields, page=page, limit=100)
            for folder in page_result.items:
                # Normalize empty string to None for comparison
                folder_parent = folder.parent_id if folder.parent_id else None
                if folder_parent == target_parent_id:
                    result.append(folder)
            if not page_result.has_more:
                break
            page += 1
        
        return result

    # -------------------------------------------------------------------------
    # Path resolution from ID
    # -------------------------------------------------------------------------

    def get_path(self, item_id: str, kind: str = "auto") -> Optional[str]:
        """Get the path for a note or folder given its ID.
        
        Args:
            item_id: The ID of a note or folder.
            kind: One of "folder", "note", or "auto" (default: "auto").
                  - "folder": Treat the ID as a folder ID.
                  - "note": Treat the ID as a note ID.
                  - "auto": Try note first, then folder.
            
        Returns:
            The encoded path string (with escaped slashes/backslashes),
            or None if the ID is not found.
            
        Raises:
            ValueError: If kind is not one of the valid values.
        """
        return self._path_mapping.mapId(item_id, kind=kind)
