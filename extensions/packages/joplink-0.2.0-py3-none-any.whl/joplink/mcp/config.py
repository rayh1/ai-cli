"""MCP server configuration and settings.

This module provides the `McpSettings` class for configuring the Joplink
MCP server, including Joplin connection details and server options.

Configuration is loaded with the following priority (highest to lowest):
1. Environment variables with the `JOPLINK_` prefix
2. Settings from ~/.config/joplink-mcp/settings.json (or platform equivalent)
3. Default values
"""

from __future__ import annotations

import json
import logging
import sys
from pathlib import Path
from typing import Any, ClassVar, Literal

import platformdirs
from pydantic import AnyHttpUrl, PositiveInt, SecretStr, model_validator
from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
)


# Application name used for config directory
APP_NAME = "joplink-mcp"

# Logger for config module - uses stderr directly since logging isn't configured yet
_config_logger = logging.getLogger("joplink.mcp.config")


def _log_to_stderr(message: str) -> None:
    """Log a message directly to stderr.
    
    Used during config loading before the logging system is configured.
    """
    print(f"[joplink-mcp config] {message}", file=sys.stderr)


def get_settings_file_path() -> Path:
    """Get the path to the joplink-mcp settings.json file.
    
    Returns the path to settings.json in the user's config directory:
    - Linux: ~/.config/joplink-mcp/settings.json
    - macOS: ~/Library/Application Support/joplink-mcp/settings.json
    - Windows: C:/Users/<user>/AppData/Local/joplink-mcp/settings.json
    
    Returns:
        Path to the settings.json file.
    """
    # Use appauthor=False to prevent Windows from creating a nested
    # directory structure like AppData/Local/joplink-mcp/joplink-mcp/
    config_dir = Path(platformdirs.user_config_dir(APP_NAME, appauthor=False))
    return config_dir / "settings.json"


def load_settings_from_json_file(
    settings_path: Path | None = None,
    log_to_stderr: bool = False,
) -> dict[str, Any]:
    """Load settings from the JSON settings file.
    
    Args:
        settings_path: Optional path to settings file. If None, uses default path.
        log_to_stderr: If True, log messages directly to stderr (useful during
            early startup before logging is configured).
        
    Returns:
        Dictionary of settings loaded from file, or empty dict if file doesn't exist
        or is invalid.
    """
    if settings_path is None:
        settings_path = get_settings_file_path()
    
    if log_to_stderr:
        _log_to_stderr(f"Looking for settings file at: {settings_path}")
    
    if not settings_path.exists():
        if log_to_stderr:
            _log_to_stderr(f"Settings file not found: {settings_path}")
        return {}
    
    if log_to_stderr:
        _log_to_stderr(f"Settings file found: {settings_path}")
    
    try:
        with open(settings_path, "r", encoding="utf-8") as f:
            content = f.read()
        
        # Check for BOM and warn if present
        if content.startswith('\ufeff'):
            if log_to_stderr:
                _log_to_stderr(
                    "WARNING: Settings file has UTF-8 BOM marker. "
                    "Consider re-saving without BOM."
                )
            content = content[1:]  # Strip BOM
        
        data = json.loads(content)
        
        if isinstance(data, dict):
            if log_to_stderr:
                # Log which settings were found (redact sensitive values)
                safe_keys = [k for k in data.keys() if 'token' not in k.lower()]
                sensitive_keys = [k for k in data.keys() if 'token' in k.lower()]
                _log_to_stderr(
                    f"Loaded {len(data)} setting(s) from file: "
                    f"{', '.join(safe_keys)}"
                    f"{' (plus ' + str(len(sensitive_keys)) + ' sensitive)' if sensitive_keys else ''}"
                )
            return data
        else:
            if log_to_stderr:
                _log_to_stderr(
                    f"WARNING: Settings file content is not a JSON object "
                    f"(got {type(data).__name__})"
                )
            return {}
    except json.JSONDecodeError as e:
        if log_to_stderr:
            _log_to_stderr(
                f"ERROR: Failed to parse settings file as JSON: {e}"
            )
        return {}
    except IOError as e:
        if log_to_stderr:
            _log_to_stderr(
                f"ERROR: Failed to read settings file: {e}"
            )
        return {}


class JsonFileSettingsSource(PydanticBaseSettingsSource):
    """Custom settings source that reads from a JSON file."""

    def __init__(
        self,
        settings_cls: type[BaseSettings],
        settings_path: Path | None = None,
        log_to_stderr: bool = False,
    ):
        super().__init__(settings_cls)
        self._settings_path = settings_path
        self._log_to_stderr = log_to_stderr
        self._json_data: dict[str, Any] | None = None

    def _load_json_data(self) -> dict[str, Any]:
        """Load and cache JSON data from file."""
        if self._json_data is None:
            self._json_data = load_settings_from_json_file(
                self._settings_path,
                log_to_stderr=self._log_to_stderr,
            )
        return self._json_data

    def get_field_value(
        self, field: Any, field_name: str
    ) -> tuple[Any, str, bool]:
        """Get value for a field from JSON file.
        
        Returns:
            Tuple of (value, field_name, is_complex). is_complex indicates if
            the value needs further parsing.
        """
        json_data = self._load_json_data()
        value = json_data.get(field_name)
        return value, field_name, False

    def __call__(self) -> dict[str, Any]:
        """Return all settings from JSON file."""
        return self._load_json_data()


class McpSettings(BaseSettings):
    """Configuration settings for the Joplink MCP server.
    
    Settings are loaded with the following priority (highest to lowest):
    1. Environment variables with the `JOPLINK_` prefix
       (e.g., `joplin_base_url` is loaded from `JOPLINK_JOPLIN_BASE_URL`)
    2. Settings from ~/.config/joplink-mcp/settings.json
    3. Default values
    
    Attributes:
        joplin_base_url: Base URL of the Joplin Data API server 
            (default: "http://localhost:41184").
        joplin_token: API token for authenticating with Joplin. If not set via
            JOPLINK_JOPLIN_TOKEN or settings.json, it will be read from the 
            "api.token" key in the Joplin settings file specified by 
            joplin_settings_path.
        joplin_settings: Path to the Joplin settings file (default:
            ~/.config/joplin-desktop/settings.json).
        joplin_timeout_seconds: Request timeout in seconds (default: 30).
        log_level: Logging verbosity level (default: "INFO").
        log_file: Optional path to log file. If set, logs will be written to 
            this file in addition to stderr.
        mcp_server_name: Name for the MCP server (default: "joplink-mcp").
        mcp_server_version: Version string for the MCP server.
        macros: Optional dictionary mapping macro names (without '@') to path
            templates with strftime-style date/time placeholders. Example:
            {"worklog": "Work/Logs/%Y/%m/%Y-%m-%d"}. User-defined macros
            override built-in macros when names match.
        tools: Optional list of tool names to enable. If None (default), all
            known tools are enabled. If an empty list, no tools are enabled.
            If a non-empty list, only the specified tools are enabled.
            Can be set via the JOPLINK_TOOLS environment variable using JSON
            array encoding (e.g., '["get_note", "save_note"]').
    
    Example:
        >>> import os
        >>> os.environ["JOPLINK_JOPLIN_TOKEN"] = "my-secret-token"
        >>> settings = McpSettings()
        >>> settings.joplin_base_url
        Url('http://localhost:41184/')
    """
    
    model_config = SettingsConfigDict(
        env_prefix="JOPLINK_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )
    
    # Class variable to allow overriding settings file path for testing
    _settings_file_path: ClassVar[Path | None] = None
    # Class variable to enable stderr logging during settings load
    _log_to_stderr: ClassVar[bool] = False

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        """Customize settings sources to add JSON file support.
        
        Priority order (highest to lowest):
        1. init_settings (constructor arguments)
        2. env_settings (environment variables)
        3. dotenv_settings (.env file)
        4. json_file_settings (settings.json file)
        5. file_secret_settings (secrets from files)
        
        Returns:
            Tuple of settings sources in priority order.
        """
        json_file_settings = JsonFileSettingsSource(
            settings_cls,
            cls._settings_file_path,
            log_to_stderr=cls._log_to_stderr,
        )
        return (
            init_settings,
            env_settings,
            dotenv_settings,
            json_file_settings,
            file_secret_settings,
        )
    
    joplin_base_url: AnyHttpUrl = "http://localhost:41184"  # type: ignore[assignment]
    joplin_token: SecretStr | None = None
    joplin_settings: str = "~/.config/joplin-desktop/settings.json"
    joplin_timeout_seconds: PositiveInt | None = 30
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    log_file: str | None = None
    mcp_server_name: str = "joplink-mcp"
    mcp_server_version: str = "0.1.0"
    macros: dict[str, str] | None = None
    tools: list[str] | None = None

    @model_validator(mode="after")
    def validate_joplin_token(self) -> McpSettings:
        """Validate and set joplin_token from settings file if not provided."""
        if self.joplin_token is None:
            settings_path = Path(self.joplin_settings).expanduser()
            if settings_path.exists():
                try:
                    with open(settings_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    token = data.get("api.token")
                    if token and isinstance(token, str):
                        # Remove surrounding quotes if present
                        token = token.strip('"').strip("'")
                        self.joplin_token = SecretStr(token)
                    else:
                        raise ValueError("api.token not found or invalid in settings file")
                except (json.JSONDecodeError, KeyError, IOError) as e:
                    raise ValueError(f"Failed to read token from settings file: {e}")
            else:
                raise ValueError("JOPLINK_JOPLIN_TOKEN not set and settings file not found")
        return self


def load_settings_with_logging() -> McpSettings:
    """Load MCP settings with detailed logging to stderr.
    
    This function loads settings and logs information about where each
    setting value came from (environment variable, settings file, or default).
    
    This is useful for debugging configuration issues, especially when
    running the MCP server and the logging system hasn't been configured yet.
    
    Returns:
        Validated McpSettings instance.
    """
    import os
    
    _log_to_stderr("Loading MCP settings...")
    _log_to_stderr(f"Expected settings file path: {get_settings_file_path()}")
    
    # Log relevant environment variables (without sensitive values)
    env_vars = {k: v for k, v in os.environ.items() if k.startswith("JOPLINK_")}
    if env_vars:
        safe_vars = {
            k: ("***" if "TOKEN" in k.upper() else v)
            for k, v in env_vars.items()
        }
        _log_to_stderr(f"Found JOPLINK_ environment variables: {safe_vars}")
    else:
        _log_to_stderr("No JOPLINK_ environment variables found")
    
    # Enable stderr logging for settings load
    McpSettings._log_to_stderr = True
    try:
        settings = McpSettings()  # type: ignore[call-arg]
    finally:
        McpSettings._log_to_stderr = False
    
    # Log final effective settings
    _log_to_stderr("Effective settings:")
    _log_to_stderr(f"  log_level: {settings.log_level}")
    _log_to_stderr(f"  log_file: {settings.log_file}")
    _log_to_stderr(f"  joplin_base_url: {settings.joplin_base_url}")
    _log_to_stderr(f"  joplin_timeout_seconds: {settings.joplin_timeout_seconds}")
    _log_to_stderr(f"  macros: {settings.macros}")
    _log_to_stderr(f"  mcp_server_name: {settings.mcp_server_name}")
    _log_to_stderr(f"  mcp_server_version: {settings.mcp_server_version}")
    
    # Log tools configuration
    if settings.tools is None:
        _log_to_stderr("  tools: None (all tools enabled)")
    elif settings.tools == []:
        _log_to_stderr("  tools: [] (no tools enabled)")
    else:
        _log_to_stderr(f"  tools: {settings.tools} ({len(settings.tools)} tool(s) enabled)")
    
    return settings
