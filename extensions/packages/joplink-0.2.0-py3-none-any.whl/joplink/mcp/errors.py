"""MCP error types and mapping utilities.

This module defines the error model for the MCP server, including error codes,
error payloads, and utilities for mapping Joplin client errors to MCP errors.

The error handling follows the principle of surfacing failures consistently
without leaking sensitive information.

Error Mapping
-------------
Joplin client exceptions are mapped to MCP error codes as follows:

- ``JoplinNotFoundError`` → ``McpErrorCode.NOT_FOUND``
    Raised when a note, folder, or tag cannot be found by ID or path.
- ``JoplinPathError`` → ``McpErrorCode.INVALID_ARGUMENT``
    Raised for invalid path syntax (e.g., unescaped special characters,
    malformed path segments).
- ``JoplinClientError`` → ``McpErrorCode.UPSTREAM_ERROR``
    Raised for upstream Joplin Data API failures (network errors, HTTP errors,
    unexpected responses).
- Other exceptions → ``McpErrorCode.INTERNAL``
    Unexpected errors that indicate bugs or unhandled conditions.

Usage with handle_mcp_errors
----------------------------
MCP tool functions decorated with ``@handle_mcp_errors`` automatically:

1. Catch known Joplin exceptions.
2. Log structured error events with the mapped ``McpErrorCode``.
3. Re-raise the original exception for the MCP server to serialize.

The FastMCP framework handles the final serialization to MCP error responses.

Example Error Payload
---------------------
When an error occurs, ``McpErrorPayload`` produces JSON like::

    {
        "code": "NOT_FOUND",
        "message": "Note not found: projects/nonexistent",
        "details": {
            "tool": "joplin_get_note",
            "resource_id": "projects/nonexistent"
        }
    }
"""

from __future__ import annotations

import functools
import logging
from enum import Enum
from typing import Any, Callable, TypeVar

from pydantic import BaseModel

from joplink import (
    JoplinClientError,
    JoplinNotFoundError,
    JoplinPathError,
)


logger = logging.getLogger("joplink.mcp")


class InvalidToolsConfigurationError(Exception):
    """Raised when the tools configuration contains unknown tool names.
    
    Attributes:
        unknown_tools: List of tool names that are not recognized.
        known_tools: List of all known/registered tool names.
    """
    
    def __init__(self, unknown_tools: list[str], known_tools: list[str]):
        """Initialize the error.
        
        Args:
            unknown_tools: List of unknown tool names from configuration.
            known_tools: List of all known tool names.
        """
        self.unknown_tools = unknown_tools
        self.known_tools = known_tools
        
        unknown_str = ", ".join(sorted(unknown_tools))
        known_str = ", ".join(sorted(known_tools))
        message = (
            f"Unknown tool(s) in configuration: {unknown_str}. "
            f"Known tools: {known_str}"
        )
        super().__init__(message)


class McpErrorCode(str, Enum):
    """Error codes for MCP error responses.
    
    These codes categorize errors for MCP clients, enabling appropriate
    handling based on error type.
    """
    
    NOT_FOUND = "NOT_FOUND"
    """Resource (note, folder, tag) was not found."""
    
    INVALID_ARGUMENT = "INVALID_ARGUMENT"
    """Invalid input argument (e.g., malformed path, invalid ID)."""
    
    CONFLICT = "CONFLICT"
    """Operation conflicts with current state (e.g., duplicate name)."""
    
    UPSTREAM_ERROR = "UPSTREAM_ERROR"
    """Error from the Joplin Data API."""
    
    INTERNAL = "INTERNAL"
    """Unexpected internal error."""
    
    CONFIG_ERROR = "CONFIG_ERROR"
    """Server configuration error."""
    
    INVALID_TOOLS_CONFIG = "INVALID_TOOLS_CONFIG"
    """Invalid tools configuration (unknown tool names)."""


class McpErrorPayload(BaseModel):
    """Structured error payload for MCP error responses.
    
    This model provides a consistent structure for error information
    that can be serialized to JSON and returned to MCP clients.
    
    Attributes:
        code: The error classification code.
        message: Human-readable error message.
        details: Optional additional error details.
    """
    
    code: McpErrorCode
    message: str
    details: dict[str, Any] | None = None


def map_error_to_code(exc: Exception) -> McpErrorCode:
    """Map an exception to an MCP error code.
    
    Args:
        exc: The exception to map.
        
    Returns:
        The corresponding MCP error code.
        
    Examples:
        >>> from joplink import JoplinNotFoundError
        >>> map_error_to_code(JoplinNotFoundError("not found"))
        <McpErrorCode.NOT_FOUND: 'NOT_FOUND'>
    """
    if isinstance(exc, JoplinNotFoundError):
        return McpErrorCode.NOT_FOUND
    elif isinstance(exc, JoplinPathError):
        return McpErrorCode.INVALID_ARGUMENT
    elif isinstance(exc, JoplinClientError):
        return McpErrorCode.UPSTREAM_ERROR
    else:
        return McpErrorCode.INTERNAL


def create_error_payload(
    exc: Exception,
    *,
    tool_name: str | None = None,
    resource_id: str | None = None,
) -> McpErrorPayload:
    """Create an error payload from an exception.
    
    Args:
        exc: The exception to convert.
        tool_name: Optional tool name for context.
        resource_id: Optional resource ID for context.
        
    Returns:
        An MCP error payload with appropriate code and message.
    """
    code = map_error_to_code(exc)
    message = str(exc) if str(exc) else exc.__class__.__name__
    
    details: dict[str, Any] = {}
    if tool_name:
        details["tool"] = tool_name
    if resource_id:
        details["resource_id"] = resource_id
    
    return McpErrorPayload(
        code=code,
        message=message,
        details=details if details else None,
    )


F = TypeVar("F", bound=Callable[..., Any])


def handle_mcp_errors(
    tool_name: str | None = None,
) -> Callable[[F], F]:
    """Decorator for handling errors in MCP tool functions.
    
    This decorator catches known Joplin errors and converts them to
    appropriate MCP error responses, logging structured error information.
    
    Args:
        tool_name: Optional tool name for logging context.
        
    Returns:
        A decorator that wraps the function with error handling.
        
    Example:
        >>> @handle_mcp_errors(tool_name="joplin_get_note")
        ... def get_note(note_ref: str) -> dict:
        ...     # Implementation
        ...     pass
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            name = tool_name or func.__name__
            try:
                return func(*args, **kwargs)
            except JoplinNotFoundError as exc:
                logger.warning(
                    "Resource not found",
                    extra={
                        "event": "tool_error",
                        "tool": name,
                        "error_code": McpErrorCode.NOT_FOUND.value,
                        "exception_type": type(exc).__name__,
                        "error_message": str(exc),
                    },
                )
                raise
            except JoplinPathError as exc:
                logger.warning(
                    "Invalid path argument",
                    extra={
                        "event": "tool_error",
                        "tool": name,
                        "error_code": McpErrorCode.INVALID_ARGUMENT.value,
                        "exception_type": type(exc).__name__,
                        "error_message": str(exc),
                    },
                )
                raise
            except JoplinClientError as exc:
                logger.error(
                    "Joplin client error",
                    extra={
                        "event": "tool_error",
                        "tool": name,
                        "error_code": McpErrorCode.UPSTREAM_ERROR.value,
                        "exception_type": type(exc).__name__,
                        "error_message": str(exc),
                    },
                )
                raise
            except Exception as exc:
                logger.exception(
                    "Unexpected error in tool",
                    extra={
                        "event": "tool_error",
                        "tool": name,
                        "error_code": McpErrorCode.INTERNAL.value,
                        "exception_type": type(exc).__name__,
                    },
                )
                raise
        return wrapper  # type: ignore[return-value]
    return decorator
