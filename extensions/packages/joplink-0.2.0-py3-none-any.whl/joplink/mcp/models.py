"""MCP models for Joplink tools.

This module re-exports Joplin models for convenient access from the MCP layer.
"""

from __future__ import annotations

import json
from typing import Annotated, Any

from pydantic import BeforeValidator

# Re-export Joplin models for convenience
from joplink.models import JoplinFolder, JoplinNote, JoplinTag


def _parse_string_list(value: Any) -> list[str] | None:
    """Parse a value that may be a list or a JSON-encoded string list.
    
    Some MCP clients send list parameters as JSON strings instead of actual lists.
    This validator handles both cases.
    
    Args:
        value: The input value - either a list, a JSON string, or None.
        
    Returns:
        A list of strings, or None if the input was None.
        
    Raises:
        ValueError: If the value cannot be parsed as a list of strings.
    """
    if value is None:
        return None
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, list):
                return parsed
        except json.JSONDecodeError:
            pass
        raise ValueError(f"Could not parse '{value}' as a list. Expected a JSON array like [\"field1\", \"field2\"].")
    raise ValueError(f"Expected a list or JSON string, got {type(value).__name__}.")


# Type alias for fields parameter that accepts both list and JSON string
FieldsList = Annotated[list[str] | None, BeforeValidator(_parse_string_list)]


__all__ = [
    "JoplinNote",
    "JoplinFolder",
    "JoplinTag",
    "FieldsList",
]
