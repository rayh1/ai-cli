"""MCP server factory and lifecycle management.

This module provides the main entry points for creating and running
the Joplink MCP server.
"""

from __future__ import annotations

import json
import logging
import sys
from typing import TYPE_CHECKING

from fastmcp import FastMCP

from joplink import HighLevelJoplinClient, JoplinClient
from joplink.low_level.base import JoplinConfig

from .config import McpSettings, load_settings_with_logging
from .errors import InvalidToolsConfigurationError
from .tools import get_known_tools, register_tools

if TYPE_CHECKING:
    pass


logger = logging.getLogger("joplink.mcp")


def load_settings(verbose: bool = False) -> McpSettings:
    """Load MCP server settings from environment variables.
    
    Args:
        verbose: If True, log detailed information about settings sources
            to stderr. Useful for debugging configuration issues.
    
    Returns:
        Validated McpSettings instance.
        
    Raises:
        ValidationError: If required settings are missing or invalid.
        
    Note:
        Sensitive values like `joplin_token` are not logged.
    """
    if verbose:
        return load_settings_with_logging()
    
    settings = McpSettings()  # type: ignore[call-arg]
    
    # Log configuration at DEBUG level, redacting sensitive values
    logger.debug(
        "Loaded MCP settings",
        extra={
            "event": "config_loaded",
            "joplin_base_url": str(settings.joplin_base_url),
            "joplin_timeout_seconds": settings.joplin_timeout_seconds,
            "log_level": settings.log_level,
            "log_file": settings.log_file,
            "mcp_server_name": settings.mcp_server_name,
            "mcp_server_version": settings.mcp_server_version,
            # Token is intentionally not logged
        },
    )
    
    return settings


class JsonFormatter(logging.Formatter):
    """JSON formatter that includes extra fields."""
    
    def format(self, record):
        # Create the base log entry
        log_entry = {
            "time": self.formatTime(record),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        
        # Add any extra fields from record attributes
        for key, value in record.__dict__.items():
            if key not in ['name', 'msg', 'args', 'levelname', 'levelno', 'pathname', 'filename', 'module', 'exc_info', 'exc_text', 'stack_info', 'lineno', 'funcName', 'created', 'msecs', 'relativeCreated', 'thread', 'threadName', 'processName', 'process', 'getMessage', 'message']:
                log_entry[key] = value
        
        return json.dumps(log_entry)


def _resolve_relative_file_path(file: str) -> str:
    """Resolve a file path, making relative paths relative to the executable.
    
    When running as a PyInstaller frozen executable, relative paths are resolved
    relative to the directory containing the executable.
    
    For absolute paths or when running as a normal Python script, the path is
    returned unchanged (or with ~ expanded).
    
    Args:
        log_file: The log file path to resolve.
        
    Returns:
        The resolved absolute path to the log file.
    """
    from pathlib import Path
    
    path = Path(file).expanduser()
    
    # If it's already absolute, return as-is
    if path.is_absolute():
        return str(path)
    
    # For relative paths, resolve relative to executable directory when frozen
    if getattr(sys, 'frozen', False):
        # Running as a PyInstaller bundle - resolve relative to executable
        exe_dir = Path(sys.executable).parent
        return str(exe_dir / path)
    
    # Running as normal Python script - use current working directory (default behavior)
    return str(path)


def _configure_logging(log_level: str, log_file: str | None = None) -> None:
    """Configure logging for the MCP server.
    
    Args:
        log_level: The log level string (DEBUG, INFO, WARNING, ERROR).
        log_file: Optional path to log file. If provided, logs will be written to this file.
            Relative paths are resolved relative to the executable when running as
            a frozen PyInstaller bundle.
    """
    level = getattr(logging, log_level.upper(), logging.INFO)
    
    # Configure the joplink.mcp logger
    mcp_logger = logging.getLogger("joplink.mcp")
    mcp_logger.setLevel(level)
    
    # Only add handlers if none exist (avoid duplicate handlers)
    if not mcp_logger.handlers:
        formatter = JsonFormatter()
        
        # Always add stderr handler
        stderr_handler = logging.StreamHandler(sys.stderr)
        stderr_handler.setLevel(level)
        stderr_handler.setFormatter(formatter)
        mcp_logger.addHandler(stderr_handler)
        
        # Add file handler if log_file is specified
        if log_file:
            resolved_log_file = _resolve_relative_file_path(log_file)
            try:
                file_handler = logging.FileHandler(resolved_log_file)
                file_handler.setLevel(level)
                file_handler.setFormatter(formatter)
                mcp_logger.addHandler(file_handler)
                mcp_logger.info(
                    "Logging to file enabled",
                    extra={"event": "log_file_enabled", "log_file": resolved_log_file}
                )
            except (OSError, IOError) as e:
                mcp_logger.warning(
                    "Failed to open log file, continuing with stderr only",
                    extra={"event": "log_file_error", "log_file": resolved_log_file, "error": str(e)}
                )


def _compute_enabled_tools(
    settings: McpSettings,
    known_tools: list[str],
) -> list[str]:
    """Compute the list of tools to enable based on settings.
    
    Args:
        settings: MCP settings with optional tools configuration.
        known_tools: List of all known tool names from the registry.
        
    Returns:
        List of tool names to enable.
        
    Raises:
        InvalidToolsConfigurationError: If unknown tool names are configured.
    """
    # Case 1: tools is None -> enable all tools
    if settings.tools is None:
        return known_tools
    
    # Case 2: tools is empty list -> enable no tools
    if settings.tools == []:
        return []
    
    # Case 3: tools is non-empty list -> validate and return
    known_set = set(known_tools)
    configured_set = set(settings.tools)
    unknown_tools = configured_set - known_set
    
    if unknown_tools:
        raise InvalidToolsConfigurationError(
            unknown_tools=sorted(unknown_tools),
            known_tools=known_tools,
        )
    
    # Return in configured order, preserving user's preference
    return settings.tools


def create_mcp_server(
    settings: McpSettings | None = None,
    verbose: bool = False,
) -> FastMCP:
    """Create and configure the Joplink MCP server.
    
    This factory function creates a fully configured FastMCP server with
    all Joplin tools registered.
    
    Args:
        settings: Optional pre-loaded settings. If None, settings are
            loaded from environment variables.
        verbose: If True, log detailed information about settings sources
            to stderr during startup. Useful for debugging configuration issues.
            
    Returns:
        A configured FastMCP server instance ready to run.
        
    Example:
        >>> server = create_mcp_server()
        >>> server.run()
    """
    if settings is None:
        settings = load_settings(verbose=verbose)
    
    # Configure logging
    _configure_logging(settings.log_level, settings.log_file)
    
    logger.info(
        "Creating MCP server",
        extra={
            "event": "server_create",
            "server_name": settings.mcp_server_name,
            "server_version": settings.mcp_server_version,
        },
    )
    
    # Create Joplin clients
    config = JoplinConfig(
        base_url=str(settings.joplin_base_url).rstrip("/"),
        token=settings.joplin_token.get_secret_value(),
        timeout=float(settings.joplin_timeout_seconds or 30),
    )
    joplin_client = JoplinClient(config)
    
    # Create PathMapping with user-defined macros from settings
    from joplink.path_mapping import PathMapping
    path_mapping = PathMapping(
        joplin_client.folders,
        joplin_client.notes,
        user_macros=settings.macros,
    )
    
    # Create high-level client with configured PathMapping
    high_level_client = HighLevelJoplinClient(joplin_client, path_mapping)
    
    # Compute enabled tools based on configuration
    known_tools = get_known_tools()
    enabled_tools = _compute_enabled_tools(settings, known_tools)
    
    # Log tools configuration
    if settings.tools is None:
        logger.info(
            "Tools configuration: all tools enabled (no whitelist configured)",
            extra={
                "event": "tools_config",
                "tools_config": "all",
                "enabled_count": len(enabled_tools),
                "enabled_tools": enabled_tools,
            },
        )
    elif settings.tools == []:
        logger.info(
            "Tools configuration: no tools enabled (empty whitelist)",
            extra={
                "event": "tools_config",
                "tools_config": "none",
                "enabled_count": 0,
                "enabled_tools": [],
            },
        )
    else:
        logger.info(
            f"Tools configuration: {len(enabled_tools)} tool(s) enabled via whitelist",
            extra={
                "event": "tools_config",
                "tools_config": "whitelist",
                "enabled_count": len(enabled_tools),
                "enabled_tools": enabled_tools,
            },
        )
    
    # Create FastMCP server
    mcp = FastMCP(
        name=settings.mcp_server_name,
        version=settings.mcp_server_version,
        instructions=(
            "You are a Joplin note-taking assistant. Use the provided tools to read and edit notes, folders, and tags."
            "Prefer entity IDs over paths when available."
            "Don't make extra API calls just to get an ID - use what you already have. "
            "Use IDs from operation responses for subsequent operations."
        ),
    )
    
    # Register enabled tools
    # Note: empty list [] should register no tools, None should register all
    register_tools(mcp, high_level_client, enabled_tools)
    
    logger.info(
        "MCP server created successfully",
        extra={
            "event": "server_ready",
            "server_name": settings.mcp_server_name,
        },
    )
    
    return mcp


def main() -> None:
    """CLI entrypoint for the MCP server.
    
    This function creates and runs the MCP server, handling startup
    and shutdown events. Verbose logging is enabled by default to help
    diagnose configuration issues.
    """
    try:
        # Use verbose=True to log settings sources to stderr during startup
        # This helps users debug configuration issues
        server = create_mcp_server(verbose=True)
        logger.info("Starting Joplink MCP server", extra={"event": "server_start"})
        server.run()
    except Exception as exc:
        logger.exception(
            "Failed to start MCP server",
            extra={"event": "server_error", "error": str(exc)},
        )
        sys.exit(1)
    finally:
        logger.info("Joplink MCP server stopped", extra={"event": "server_stop"})


if __name__ == "__main__":
    main()
