"""Joplink MCP server package.

This package provides an MCP (Model Context Protocol) server that wraps
the high-level Joplin client operations, exposing them as MCP tools.

The server can be started using the `create_mcp_server` factory function
or via the CLI entrypoint.

Example:
    >>> from joplink.mcp import create_mcp_server
    >>> server = create_mcp_server()
    >>> server.run()
"""

from .server import create_mcp_server

__all__ = ["create_mcp_server"]
