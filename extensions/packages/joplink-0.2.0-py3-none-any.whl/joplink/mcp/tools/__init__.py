"""MCP tool registration for Joplink.

This module provides the `register_all_tools` function that registers
all Joplin-related MCP tools on a FastMCP server instance, as well as
a tool registry for selective tool registration.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

from .folders import register_folder_tools
from .notes import register_note_tools
from .paths import register_path_tools
from .tags import register_tag_tools

if TYPE_CHECKING:
    from fastmcp import FastMCP
    
    from joplink import HighLevelJoplinClient


# Tool registry mapping tool names to their registration functions
# Each tool name maps to a callable that registers that specific tool
_TOOL_REGISTRY: dict[str, Callable[[FastMCP, HighLevelJoplinClient], None]] = {}


def _build_tool_registry() -> dict[str, Callable[[FastMCP, HighLevelJoplinClient], None]]:
    """Build the tool registry mapping tool names to registration functions.
    
    Returns:
        Dictionary mapping tool names to registration callables.
    """
    # Import individual tool registration functions to build registry
    from .folders import (
        _register_create_folder,
        _register_delete_folder,
        _register_get_folder,
        _register_list_child_folders,
        _register_move_folder,
        _register_rename_folder,
        _register_search_folders,
    )
    from .notes import (
        _register_append_to_note,
        _register_delete_note,
        _register_get_note,
        _register_list_tags_for_note,
        _register_save_note,
        _register_search_notes,
    )
    from .paths import (
        _register_get_path,
        _register_list_notes_in_folder,
    )
    from .tags import (
        _register_delete_tag,
        _register_get_tag,
        _register_list_notes_for_tag,
        _register_save_tag,
        _register_search_tags,
        _register_tag_note,
        _register_untag_note,
    )
    
    return {
        # Note tools
        "get_note": _register_get_note,
        "save_note": _register_save_note,
        "delete_note": _register_delete_note,
        "append_to_note": _register_append_to_note,
        "search_notes": _register_search_notes,
        "list_tags_for_note": _register_list_tags_for_note,
        # Folder tools
        "create_folder": _register_create_folder,
        "get_folder": _register_get_folder,
        "delete_folder": _register_delete_folder,
        "search_folders": _register_search_folders,
        "list_child_folders": _register_list_child_folders,
        "move_folder": _register_move_folder,
        "rename_folder": _register_rename_folder,
        # Tag tools
        "save_tag": _register_save_tag,
        "get_tag": _register_get_tag,
        "delete_tag": _register_delete_tag,
        "search_tags": _register_search_tags,
        "tag_note": _register_tag_note,
        "untag_note": _register_untag_note,
        "list_notes_for_tag": _register_list_notes_for_tag,
        # Path tools
        "list_notes_in_folder": _register_list_notes_in_folder,
        "get_path": _register_get_path,
    }


def get_known_tools() -> list[str]:
    """Get a list of all known tool names.
    
    Returns:
        Sorted list of all tool names in the registry.
    """
    global _TOOL_REGISTRY
    if not _TOOL_REGISTRY:
        _TOOL_REGISTRY = _build_tool_registry()
    return sorted(_TOOL_REGISTRY.keys())


def register_tools(
    mcp: FastMCP,
    client: HighLevelJoplinClient,
    tool_names: list[str] | None = None,
) -> None:
    """Register specified Joplin MCP tools on the server.
    
    This function supports selective tool registration based on a whitelist.
    If no tool names are provided, all known tools are registered.
    
    Args:
        mcp: The FastMCP server instance to register tools on.
        client: The high-level Joplin client to use for operations.
        tool_names: Optional list of tool names to register. If None, all
            tools are registered. Tool names must match exactly (case-sensitive).
        
    Example:
        >>> from fastmcp import FastMCP
        >>> from joplink import JoplinClient, HighLevelJoplinClient
        >>> mcp = FastMCP("test")
        >>> low = JoplinClient()
        >>> high = HighLevelJoplinClient(low)
        >>> # Register only specific tools
        >>> register_tools(mcp, high, ["get_note", "save_note"])
        >>> # Register all tools
        >>> register_tools(mcp, high, None)
    """
    global _TOOL_REGISTRY
    if not _TOOL_REGISTRY:
        _TOOL_REGISTRY = _build_tool_registry()
    
    # If no tool names specified, register all tools
    if tool_names is None:
        tools_to_register = list(_TOOL_REGISTRY.keys())
    else:
        tools_to_register = tool_names
    
    # Register each tool
    for tool_name in tools_to_register:
        if tool_name in _TOOL_REGISTRY:
            _TOOL_REGISTRY[tool_name](mcp, client)


def register_all_tools(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register all Joplin MCP tools on the server.
    
    This function registers all note, folder, tag, and path-based tools
    on the provided FastMCP server instance.
    
    Args:
        mcp: The FastMCP server instance to register tools on.
        client: The high-level Joplin client to use for operations.
        
    Example:
        >>> from fastmcp import FastMCP
        >>> from joplink import JoplinClient, HighLevelJoplinClient
        >>> mcp = FastMCP("test")
        >>> low = JoplinClient()
        >>> high = HighLevelJoplinClient(low)
        >>> register_all_tools(mcp, high)
    """
    register_tools(mcp, client, None)
