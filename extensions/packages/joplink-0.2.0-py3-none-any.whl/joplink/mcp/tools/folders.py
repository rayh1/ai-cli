"""MCP tools for Joplin folder operations.

This module provides MCP tools that wrap the high-level Joplin client's
folder-related methods, enabling folder CRUD and organization operations.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Annotated

from pydantic import Field

from joplink.mcp.errors import handle_mcp_errors
from joplink.mcp.models import FieldsList

if TYPE_CHECKING:
    from fastmcp import FastMCP
    
    from joplink import HighLevelJoplinClient


logger = logging.getLogger("joplink.mcp")


def _register_create_folder(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the create_folder tool."""
    
    @mcp.tool(name="create_folder")
    @handle_mcp_errors(tool_name="create_folder")
    def create_folder(
        path: Annotated[str, Field(description="Path like 'parent/child' or just 'name' for root folder.")],
        extra_fields: Annotated[dict[str, Any] | None, Field(description="Additional fields to set.")] = None,
    ) -> Annotated[str, Field(description="ID of created folder.")]:
        """Create new folder.
        """
        logger.info(
            "Creating folder",
            extra={"event": "tool_invoke", "tool": "create_folder", "path": path},
        )
        folder = client.create_folder(path, **(extra_fields or {}))
        logger.debug(
            "Folder created",
            extra={"event": "tool_result", "tool": "create_folder", "folder_id": folder.id},
        )
        return folder.id


def _register_get_folder(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the get_folder tool."""
    
    @mcp.tool(name="get_folder")
    @handle_mcp_errors(tool_name="get_folder")
    def get_folder(
        folder_ref: Annotated[str, Field(description="Folder ID or path like \"parent/child\".")],
        fields: Annotated[FieldsList, Field(description="Fields to include.")] = None,
    ) -> Annotated[dict[str, Any], Field(description="Folder as dictionary.")]:
        """Get folder.
        """
        logger.info(
            "Getting folder",
            extra={"event": "tool_invoke", "tool": "get_folder", "folder_ref": folder_ref},
        )
        folder = client.get_folder(folder_ref, fields=fields)
        logger.debug(
            "Folder retrieved",
            extra={"event": "tool_result", "tool": "get_folder", "folder_id": folder.id},
        )
        return folder.model_dump(exclude_none=True)


def _register_delete_folder(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the delete_folder tool."""
    
    @mcp.tool(name="delete_folder")
    @handle_mcp_errors(tool_name="delete_folder")
    def delete_folder(folder_ref: Annotated[str, Field(description="Folder ID or path.")]) -> Annotated[dict[str, bool], Field(description="Success status.")]:
        """Delete folder.
        """
        logger.info(
            "Deleting folder",
            extra={"event": "tool_invoke", "tool": "delete_folder", "folder_ref": folder_ref},
        )
        client.delete_folder(folder_ref)
        logger.debug(
            "Folder deleted",
            extra={"event": "tool_result", "tool": "delete_folder", "folder_ref": folder_ref},
        )
        return {"success": True}


def _register_search_folders(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the search_folders tool."""
    
    @mcp.tool(name="search_folders")
    @handle_mcp_errors(tool_name="search_folders")
    def search_folders(
        query: Annotated[str | None, Field(description="Search query. If not provided, lists all folders.")] = None,
        fields: Annotated[FieldsList, Field(description="Fields to include.")] = None,
        page: Annotated[int | None, Field(description="Page number.")] = None,
        limit: Annotated[int | None, Field(description="Max results.")] = None,
    ) -> Annotated[dict[str, Any], Field(description="Paged results.")]:
        """Search folders.
        """
        logger.info(
            "Searching folders",
            extra={"event": "tool_invoke", "tool": "search_folders", "query": query},
        )
        result = client.search_folders(query, fields=fields, page=page, limit=limit)
        logger.debug(
            "Folders searched",
            extra={
                "event": "tool_result",
                "tool": "search_folders",
                "count": len(result.items),
                "has_more": result.has_more,
            },
        )
        return {
            "items": [folder.model_dump(exclude_none=True) for folder in result.items],
            "has_more": result.has_more,
            "page": result.page,
            "limit": result.limit,
        }


def _register_list_child_folders(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the list_child_folders tool."""
    
    @mcp.tool(name="list_child_folders")
    @handle_mcp_errors(tool_name="list_child_folders")
    def list_child_folders(
        folder_ref: Annotated[str | None, Field(description="Folder ID or path, not provided for root-level folders.")] = None,
        fields: Annotated[FieldsList, Field(description="Fields to include.")] = None,
    ) -> Annotated[list[dict[str, Any]], Field(description="Child folders.")]:
        """List child folders.
        """
        logger.info(
            "Listing child folders",
            extra={"event": "tool_invoke", "tool": "list_child_folders", "folder_ref": folder_ref},
        )
        folders = client.list_child_folders(folder_ref, fields=fields)
        logger.debug(
            "Child folders listed",
            extra={"event": "tool_result", "tool": "list_child_folders", "count": len(folders)},
        )
        return [folder.model_dump(exclude_none=True) for folder in folders]


def _register_move_folder(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the move_folder tool."""
    
    @mcp.tool(name="move_folder")
    @handle_mcp_errors(tool_name="move_folder")
    def move_folder(
        folder_ref: Annotated[str, Field(description="Folder ID or path to move.")],
        to_folder_ref: Annotated[str | None, Field(description="Destination folder ID or path, not provided for moving to root.")] = None,
    ) -> Annotated[str, Field(description="ID of moved folder.")]:
        """Move folder.
        """
        logger.info(
            "Moving folder",
            extra={
                "event": "tool_invoke",
                "tool": "move_folder",
                "folder_ref": folder_ref,
                "to_folder_ref": to_folder_ref,
            },
        )
        folder = client.move_folder(folder_ref, to_folder_ref=to_folder_ref)
        logger.debug(
            "Folder moved",
            extra={"event": "tool_result", "tool": "move_folder", "folder_id": folder.id},
        )
        return folder.id


def _register_rename_folder(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the rename_folder tool."""
    
    @mcp.tool(name="rename_folder")
    @handle_mcp_errors(tool_name="rename_folder")
    def rename_folder(
        folder_ref: Annotated[str, Field(description="Folder ID or path.")],
        new_title: Annotated[str, Field(description="New title.")],
    ) -> Annotated[str, Field(description="ID of renamed folder.")]:
        """Rename folder.
        """
        logger.info(
            "Renaming folder",
            extra={
                "event": "tool_invoke",
                "tool": "rename_folder",
                "folder_ref": folder_ref,
                "new_title": new_title,
            },
        )
        folder = client.rename_folder(folder_ref, new_title=new_title)
        logger.debug(
            "Folder renamed",
            extra={"event": "tool_result", "tool": "rename_folder", "folder_id": folder.id},
        )
        return folder.id


def register_folder_tools(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register folder-related MCP tools.
    
    Args:
        mcp: The FastMCP server instance.
        client: The high-level Joplin client.
    """
    _register_create_folder(mcp, client)
    _register_get_folder(mcp, client)
    _register_delete_folder(mcp, client)
    _register_search_folders(mcp, client)
    _register_list_child_folders(mcp, client)
    _register_move_folder(mcp, client)
    _register_rename_folder(mcp, client)
