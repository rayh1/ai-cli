"""MCP tools for path-based Joplin operations.

This module provides MCP tools for path-based listing operations,
enabling listing notes within specific folders and resolving IDs to paths.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Annotated

from pydantic import Field

from joplink.mcp.errors import handle_mcp_errors
from joplink.mcp.models import FieldsList
from joplink.models import paged_results_to_dict

if TYPE_CHECKING:
    from fastmcp import FastMCP
    
    from joplink import HighLevelJoplinClient


logger = logging.getLogger("joplink.mcp")


def _register_list_notes_in_folder(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the list_notes_in_folder tool."""
    
    @mcp.tool(name="list_notes_in_folder")
    @handle_mcp_errors(tool_name="list_notes_in_folder")
    def list_notes_in_folder(
        folder_ref: Annotated[str, Field(description="ID or path like \"parent/child\".")],
        fields: Annotated[FieldsList, Field(description="Fields to include.")] = None,
        page: Annotated[int | None, Field(description="Page number.")] = None,
        limit: Annotated[int | None, Field(description="Max results.")] = None,
    ) -> Annotated[dict[str, Any], Field(description="Paged results.")]:
        """List notes in folder.
        """
        logger.info(
            "Listing notes in folder",
            extra={"event": "tool_invoke", "tool": "list_notes_in_folder", "folder_ref": folder_ref},
        )
        result = client.list_notes_in_folder(
            folder_ref, fields=fields, page=page, limit=limit
        )
        logger.debug(
            "Notes in folder listed",
            extra={
                "event": "tool_result",
                "tool": "list_notes_in_folder",
                "count": len(result.items),
                "has_more": result.has_more,
            },
        )
        return paged_results_to_dict(result)


def _register_get_path(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the get_path tool."""
    
    @mcp.tool(name="get_path")
    @handle_mcp_errors(tool_name="get_path")
    def get_path(
        item_id: Annotated[str, Field(description="ID of note or folder.")],
    ) -> Annotated[str | None, Field(description="Path, or null if not found.")]:
        """Get path"""
        logger.info(
            "Getting path for ID",
            extra={"event": "tool_invoke", "tool": "get_path", "item_id": item_id},
        )
        result = client.get_path(item_id, kind="auto")
        logger.debug(
            "Path resolved",
            extra={
                "event": "tool_result",
                "tool": "get_path",
                "path": result,
            },
        )
        return result


def register_path_tools(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register path-based MCP tools.
    
    Args:
        mcp: The FastMCP server instance.
        client: The high-level Joplin client.
    """
    _register_list_notes_in_folder(mcp, client)
    _register_get_path(mcp, client)
