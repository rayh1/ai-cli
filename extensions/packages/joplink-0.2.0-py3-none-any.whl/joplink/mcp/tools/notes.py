"""MCP tools for Joplin note operations.

This module provides MCP tools that wrap the high-level Joplin client's
note-related methods, enabling note CRUD operations through MCP.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Annotated

from pydantic import Field

from joplink.mcp.errors import handle_mcp_errors
from joplink.mcp.models import FieldsList
from joplink.models import paged_results_to_dict

if TYPE_CHECKING:
    from fastmcp import FastMCP
    
    from joplink import HighLevelJoplinClient


logger = logging.getLogger("joplink.mcp")


def _register_get_note(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the get_note tool."""
    
    @mcp.tool(name="get_note")
    @handle_mcp_errors(tool_name="get_note")
    def get_note(
        note_ref: Annotated[str, Field(description="ID or path like \"folder/note\".")],
        fields: Annotated[FieldsList, Field(description="Fields to include.")] = None,
    ) -> Annotated[dict[str, Any], Field(description="Note as dictionary.")]:
        """Get note.
        """
        logger.info(
            "Getting note",
            extra={"event": "tool_invoke", "tool": "get_note", "note_ref": note_ref},
        )
        note = client.get_note(note_ref, fields=fields)
        logger.debug(
            "Note retrieved",
            extra={"event": "tool_result", "tool": "get_note", "note_id": note.id},
        )
        return note.model_dump(exclude_none=True)


def _register_save_note(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the save_note tool."""
    
    @mcp.tool(name="save_note")
    @handle_mcp_errors(tool_name="save_note")
    def save_note(
        note_ref: Annotated[str, Field(description="ID or path like \"folder/note_title\".")],
        body: Annotated[str | None, Field(description="Note body.")] = None,
        extra_fields: Annotated[dict[str, Any] | None, Field(description="Additional fields to set.")] = None,
    ) -> Annotated[str, Field(description="ID of created or updated note.")]:
        """Create or update note.
        
        If note exists (ID or path resolves), it is updated.
        If note does not exist and note_ref is a path, a new note is created.
        """
        logger.info(
            "Saving note",
            extra={"event": "tool_invoke", "tool": "save_note", "note_ref": note_ref},
        )
        fields: dict[str, Any] = {}
        if body is not None:
            fields["body"] = body
        if extra_fields:
            fields.update(extra_fields)
        
        note = client.save_note(note_ref, **fields)
        logger.debug(
            "Note saved",
            extra={"event": "tool_result", "tool": "save_note", "note_id": note.id},
        )
        return note.id


def _register_delete_note(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the delete_note tool."""
    
    @mcp.tool(name="delete_note")
    @handle_mcp_errors(tool_name="delete_note")
    def delete_note(note_ref: Annotated[str, Field(description="ID or path.")]) -> Annotated[dict[str, bool], Field(description="Success status.")]:
        """Delete note.
        """
        logger.info(
            "Deleting note",
            extra={"event": "tool_invoke", "tool": "delete_note", "note_ref": note_ref},
        )
        client.delete_note(note_ref)
        logger.debug(
            "Note deleted",
            extra={"event": "tool_result", "tool": "delete_note", "note_ref": note_ref},
        )
        return {"success": True}


def _register_append_to_note(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the append_to_note tool."""
    
    @mcp.tool(name="append_to_note")
    @handle_mcp_errors(tool_name="append_to_note")
    def append_to_note(
        note_ref: Annotated[str, Field(description="ID or path.")],
        content: Annotated[str, Field(description="Content to append.")],
        separator: Annotated[str | None, Field(description="Separator between existing and new content (default: newline).")] = None,
    ) -> Annotated[str, Field(description="ID of updated note.")]:
        """Append content, create note if it does not exist.
        """
        logger.info(
            "Appending to note",
            extra={"event": "tool_invoke", "tool": "append_to_note", "note_ref": note_ref},
        )
        sep = separator if separator is not None else "\n"
        note = client.append_to_note(note_ref, content, separator=sep)
        logger.debug(
            "Note appended",
            extra={"event": "tool_result", "tool": "append_to_note", "note_id": note.id},
        )
        return note.id


def _register_search_notes(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the search_notes tool."""
    
    @mcp.tool(name="search_notes")
    @handle_mcp_errors(tool_name="search_notes")
    def search_notes(
        query: Annotated[str | None, Field(description="Search query. If not provided, lists all notes.")] = None,
        fields: Annotated[FieldsList, Field(description="Fields to include.")] = None,
        page: Annotated[int | None, Field(description="Page number.")] = None,
        limit: Annotated[int | None, Field(description="Max results.")] = None,
    ) -> Annotated[dict[str, Any], Field(description="Paged results.")]:
        """Search notes.
        """
        logger.info(
            "Searching notes",
            extra={"event": "tool_invoke", "tool": "search_notes", "query": query},
        )
        result = client.search_notes(query, fields=fields, page=page, limit=limit)
        logger.debug(
            "Notes searched",
            extra={
                "event": "tool_result",
                "tool": "search_notes",
                "count": len(result.items),
                "has_more": result.has_more,
            },
        )
        return paged_results_to_dict(result)


def _register_list_tags_for_note(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the list_tags_for_note tool."""
    
    @mcp.tool(name="list_tags_for_note")
    @handle_mcp_errors(tool_name="list_tags_for_note")
    def list_tags_for_note(
        note_ref: Annotated[str, Field(description="ID or path like \"folder/note\".")],
        fields: Annotated[FieldsList, Field(description="Fields to include.")] = None,
        page: Annotated[int | None, Field(description="Page number.")] = None,
        limit: Annotated[int | None, Field(description="Max results.")] = None,
    ) -> Annotated[dict[str, Any], Field(description="Paged results.")]:
        """List tags for note.
        """
        logger.info(
            "Listing tags for note",
            extra={"event": "tool_invoke", "tool": "list_tags_for_note", "note_ref": note_ref},
        )
        result = client.list_tags_for_note(note_ref, fields=fields, page=page, limit=limit)
        logger.debug(
            "Tags for note listed",
            extra={
                "event": "tool_result",
                "tool": "list_tags_for_note",
                "count": len(result.items),
                "has_more": result.has_more,
            },
        )
        return paged_results_to_dict(result)


def register_note_tools(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register note-related MCP tools.
    
    Args:
        mcp: The FastMCP server instance.
        client: The high-level Joplin client.
    """
    _register_get_note(mcp, client)
    _register_save_note(mcp, client)
    _register_delete_note(mcp, client)
    _register_append_to_note(mcp, client)
    _register_search_notes(mcp, client)
    _register_list_tags_for_note(mcp, client)
