"""MCP tools for Joplin tag operations.

This module provides MCP tools that wrap the high-level Joplin client's
tag-related methods, enabling tag CRUD and note tagging operations.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Annotated

from pydantic import Field

from joplink.mcp.errors import handle_mcp_errors
from joplink.mcp.models import FieldsList
from joplink.models import paged_results_to_dict

if TYPE_CHECKING:
    from fastmcp import FastMCP
    
    from joplink import HighLevelJoplinClient


logger = logging.getLogger("joplink.mcp")


def _register_save_tag(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the save_tag tool."""
    
    @mcp.tool(name="save_tag")
    @handle_mcp_errors(tool_name="save_tag")
    def save_tag(name: Annotated[str, Field(description="Tag name/title.")]) -> Annotated[str, Field(description="ID of tag.")]:
        """Get or create tag.
        
        If tag with name exists, it is returned.
        Otherwise, a new tag is created.
        """
        logger.info(
            "Saving tag",
            extra={"event": "tool_invoke", "tool": "save_tag", "tag_name": name},
        )
        tag = client.save_tag(name)
        logger.debug(
            "Tag saved",
            extra={"event": "tool_result", "tool": "save_tag", "tag_id": tag.id},
        )
        return tag.id


def _register_get_tag(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the get_tag tool."""
    
    @mcp.tool(name="get_tag")
    @handle_mcp_errors(tool_name="get_tag")
    def get_tag(
        tag_ref: Annotated[str, Field(description="ID or title.")],
        fields: Annotated[FieldsList, Field(description="Fields to include.")] = None,
    ) -> Annotated[dict[str, Any], Field(description="Tag as dictionary.")]:
        """Get tag.
        """
        logger.info(
            "Getting tag",
            extra={"event": "tool_invoke", "tool": "get_tag", "tag_ref": tag_ref},
        )
        tag = client.get_tag(tag_ref, fields=fields)
        logger.debug(
            "Tag retrieved",
            extra={"event": "tool_result", "tool": "get_tag", "tag_id": tag.id},
        )
        return tag.model_dump(exclude_none=True)


def _register_delete_tag(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the delete_tag tool."""
    
    @mcp.tool(name="delete_tag")
    @handle_mcp_errors(tool_name="delete_tag")
    def delete_tag(tag_ref: Annotated[str, Field(description="ID or title.")]) -> Annotated[dict[str, bool], Field(description="Success status.")]:
        """Delete tag.
        """
        logger.info(
            "Deleting tag",
            extra={"event": "tool_invoke", "tool": "delete_tag", "tag_ref": tag_ref},
        )
        client.delete_tag(tag_ref)
        logger.debug(
            "Tag deleted",
            extra={"event": "tool_result", "tool": "delete_tag", "tag_ref": tag_ref},
        )
        return {"success": True}


def _register_search_tags(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the search_tags tool."""
    
    @mcp.tool(name="search_tags")
    @handle_mcp_errors(tool_name="search_tags")
    def search_tags(
        query: Annotated[str | None, Field(description="Search query. If not provided, lists all tags.")] = None,
        fields: Annotated[FieldsList, Field(description="Fields to include.")] = None,
        page: Annotated[int | None, Field(description="Page number.")] = None,
        limit: Annotated[int | None, Field(description="Max results.")] = None,
    ) -> Annotated[dict[str, Any], Field(description="Paged results.")]:
        """Search tags.
        """
        logger.info(
            "Searching tags",
            extra={"event": "tool_invoke", "tool": "search_tags", "query": query},
        )
        result = client.search_tags(query, fields=fields, page=page, limit=limit)
        logger.debug(
            "Tags searched",
            extra={
                "event": "tool_result",
                "tool": "search_tags",
                "count": len(result.items),
                "has_more": result.has_more,
            },
        )
        return paged_results_to_dict(result)


def _register_tag_note(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the tag_note tool."""
    
    @mcp.tool(name="tag_note")
    @handle_mcp_errors(tool_name="tag_note")
    def tag_note(
        note_ref: Annotated[str, Field(description="ID or path.")],
        tag_ref: Annotated[str, Field(description="ID or title.")],
    ) -> Annotated[dict[str, bool], Field(description="Success status.")]:
        """Add tag to note.
        
        If tag_ref is title (not ID), the tag is created if it doesn't exist.
        """
        logger.info(
            "Tagging note",
            extra={
                "event": "tool_invoke",
                "tool": "tag_note",
                "note_ref": note_ref,
                "tag_ref": tag_ref,
            },
        )
        client.tag_note(note_ref, tag_ref)
        logger.debug(
            "Note tagged",
            extra={"event": "tool_result", "tool": "tag_note", "note_ref": note_ref, "tag_ref": tag_ref},
        )
        return {"success": True}


def _register_untag_note(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the untag_note tool."""
    
    @mcp.tool(name="untag_note")
    @handle_mcp_errors(tool_name="untag_note")
    def untag_note(
        note_ref: Annotated[str, Field(description="ID or path.")],
        tag_ref: Annotated[str, Field(description="ID or title.")],
    ) -> Annotated[dict[str, bool], Field(description="Success status.")]:
        """Remove tag from note.
        """
        logger.info(
            "Untagging note",
            extra={
                "event": "tool_invoke",
                "tool": "untag_note",
                "note_ref": note_ref,
                "tag_ref": tag_ref,
            },
        )
        client.untag_note(note_ref, tag_ref)
        logger.debug(
            "Note untagged",
            extra={"event": "tool_result", "tool": "untag_note", "note_ref": note_ref, "tag_ref": tag_ref},
        )
        return {"success": True}


def _register_list_notes_for_tag(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register the list_notes_for_tag tool."""
    
    @mcp.tool(name="list_notes_for_tag")
    @handle_mcp_errors(tool_name="list_notes_for_tag")
    def list_notes_for_tag(
        tag_ref: Annotated[str, Field(description="ID or title.")],
        fields: Annotated[FieldsList, Field(description="Fields to include.")] = None,
        page: Annotated[int | None, Field(description="Page number.")] = None,
        limit: Annotated[int | None, Field(description="Max results.")] = None,
    ) -> Annotated[dict[str, Any], Field(description="Paged results.")]:
        """List notes associated with tag.
        """
        logger.info(
            "Listing notes for tag",
            extra={"event": "tool_invoke", "tool": "list_notes_for_tag", "tag_ref": tag_ref},
        )
        result = client.list_notes_for_tag(tag_ref, fields=fields, page=page, limit=limit)
        logger.debug(
            "Notes for tag listed",
            extra={
                "event": "tool_result",
                "tool": "list_notes_for_tag",
                "count": len(result.items),
                "has_more": result.has_more,
            },
        )
        return paged_results_to_dict(result)


def register_tag_tools(mcp: FastMCP, client: HighLevelJoplinClient) -> None:
    """Register tag-related MCP tools.
    
    Args:
        mcp: The FastMCP server instance.
        client: The high-level Joplin client.
    """
    _register_save_tag(mcp, client)
    _register_get_tag(mcp, client)
    _register_delete_tag(mcp, client)
    _register_search_tags(mcp, client)
    _register_tag_note(mcp, client)
    _register_untag_note(mcp, client)
    _register_list_notes_for_tag(mcp, client)
