#!/usr/bin/env python
"""Entry point for PyInstaller builds of Joplink MCP server."""

if __name__ == "__main__":
    from joplink.mcp.server import main
    main()
