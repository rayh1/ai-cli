from __future__ import annotations

from typing import Any, Dict, Iterable, Optional, overload, Literal

from .base import BaseService
from ..models import PagedResults, JoplinNote, JoplinFolder, JoplinTag, DEFAULT_PAGE, DEFAULT_LIMIT

"""Search service facade.

Provides a typed `SearchResults` container when performing searches
through the Joplin API.
"""


class SearchService(BaseService):
    @overload
    def search(
        self,
        query: str,
        *,
        search_type: None = None,
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> PagedResults[JoplinNote]: ...

    @overload
    def search(
        self,
        query: str,
        *,
        search_type: Literal["note"],
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> PagedResults[JoplinNote]: ...

    @overload
    def search(
        self,
        query: str,
        *,
        search_type: Literal["folder"],
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> PagedResults[JoplinFolder]: ...

    @overload
    def search(
        self,
        query: str,
        *,
        search_type: Literal["tag"],
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> PagedResults[JoplinTag]: ...

    def search(
        self,
        query: str,
        *,
        search_type: Optional[str] = None,
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> PagedResults[JoplinNote] | PagedResults[JoplinFolder] | PagedResults[JoplinTag]:
        """Search for entities matching a query string.
        Args:
            query: The search query string.
            search_type: Optional type of entity to search for ("note", "folder", "tag"). Defaults to "note".
            fields: Optional iterable of field names to include in the response.
            page: Optional page number for pagination.
            limit: Optional number of items per page.
        Returns:
            PagedResults of the appropriate type based on search_type.
        """
        model_mapping = {
            "note": JoplinNote,
            "folder": JoplinFolder,
            "tag": JoplinTag,
        }
        effective_type = search_type or "note"
        model_cls = model_mapping.get(effective_type, JoplinNote)
        effective_page = page if page is not None else DEFAULT_PAGE
        effective_limit = limit if limit is not None else DEFAULT_LIMIT
        params: Dict[str, Any] = {"query": query}
        if search_type is not None:
            params["type"] = search_type
        # Merge the common pagination/listing params via helper to ensure all
        # services remain consistent when building request params.
        params.update(self._build_pagination_params(
            fields=fields,
            page=effective_page,
            limit=effective_limit,
        ))
        raw = self._request("GET", "search", params=params)
        items = [model_cls.model_validate(it) for it in raw.get("items", [])]
        return PagedResults[model_cls](
            items=items,
            has_more=bool(raw.get("has_more", False)),
            page=effective_page,
            limit=effective_limit,
        )
