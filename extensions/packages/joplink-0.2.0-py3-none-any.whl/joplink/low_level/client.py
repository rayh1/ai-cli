from __future__ import annotations

from dataclasses import dataclass

from .base import JoplinConfig
from .ping_service import PingService
from .folders_service import FoldersService
from .notes_service import NotesService
from .search_service import SearchService
from .tags_service import TagsService


@dataclass
class JoplinClient:
    """Main client facade for the Joplin Data API.

    This module provides `JoplinClient`, a convenience wrapper that groups
    service objects (`notes`, `folders`, `tags`, `search`) and exposes a
    minimal high-level API for calling Joplin Data API endpoints.

    Configuration (base url and token) is centralized via the `JoplinConfig`
    dataclass defined in `src/joplink/base.py`.
    """

    config: JoplinConfig

    def __init__(self, config: JoplinConfig | None = None) -> None:
        if config is None:
            config = JoplinConfig()
        self.config = config

        self.ping = PingService(config=self.config)
        self.notes = NotesService(config=self.config)
        self.folders = FoldersService(config=self.config)
        self.tags = TagsService(config=self.config)
        self.search = SearchService(config=self.config)
