from __future__ import annotations

from typing import Any, Dict, Iterable, Optional, List

from .base import BaseService
from ..models import JoplinFolder, JoplinNote, PagedResults, DEFAULT_PAGE, DEFAULT_LIMIT

"""Folders service facade.

Handles listing and CRUD operations for Joplin folders (notebooks).
Returns `JoplinFolder` models for single-resource endpoints and
`SearchResults` for list endpoints.
"""


class FoldersService(BaseService):
    def list_folders(
        self,
        *,
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
        order_by: Optional[str] = None,
        order_dir: Optional[str] = None,
    ) -> PagedResults[JoplinFolder]:
        """List folders with optional pagination and sorting.
        Args:
            fields: Optional iterable of field names to include in the response.
            page: Optional page number for pagination.
            limit: Optional number of items per page.
            order_by: Optional field name to order by.
            order_dir: Optional order direction ("ASC" or "DESC").
        Returns:
            PagedResults[JoplinFolder]: A paginated list of Joplin folders.
        """
        effective_page = page if page is not None else DEFAULT_PAGE
        effective_limit = limit if limit is not None else DEFAULT_LIMIT
        params = self._build_pagination_params(
            fields=fields,
            page=effective_page,
            limit=effective_limit,
            order_by=order_by,
            order_dir=order_dir,
        )
        raw = self._request("GET", "folders", params=params)
        items = [JoplinFolder.model_validate(it) for it in raw.get("items", [])]
        return PagedResults[JoplinFolder](
            items=items,
            has_more=bool(raw.get("has_more", False)),
            page=effective_page,
            limit=effective_limit,
        )

    def get_folder(self, folder_id: str, *, fields: Optional[Iterable[str]] = None) -> JoplinFolder:
        """Get a single folder by ID.
        Args:
            folder_id: The ID of the folder to retrieve.
            fields: Optional iterable of field names to include in the response.
        Returns:
            JoplinFolder: The requested Joplin folder.
        """
        params: Dict[str, Any] = {}
        if fields is not None:
            params["fields"] = ",".join(fields)
        raw = self._request("GET", f"folders/{folder_id}", params=params)
        return JoplinFolder.model_validate(raw)

    def create_folder(self, data: Dict[str, Any]) -> JoplinFolder:
        """Create a new folder.
        Args:
            data: A dictionary containing folder fields and values.
        Returns:
            JoplinFolder: The created Joplin folder.
        """
        raw = self._request("POST", "folders", json=data)
        return JoplinFolder.model_validate(raw)

    def update_folder(self, folder_id: str, data: Dict[str, Any]) -> JoplinFolder:
        """Update an existing folder.
        Args:
            folder_id: The ID of the folder to update.
            data: A dictionary containing folder fields and values.
        Returns:
            JoplinFolder: The updated Joplin folder.
        """
        raw = self._request("PUT", f"folders/{folder_id}", json=data)
        return JoplinFolder.model_validate(raw)

    def delete_folder(self, folder_id: str) -> Any:
        """Delete a folder by ID.
        Args:
            folder_id: The ID of the folder to delete.
        Returns:
            Any: The response from the delete operation.
        """
        return self._request("DELETE", f"folders/{folder_id}")
    
    def list_notes_in_folder(
        self,
        folder_id: str,
        *,
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
        order_by: Optional[str] = None,
        order_dir: Optional[str] = None,
    ) -> PagedResults[JoplinNote]:
        """List notes within a specific folder.
        Args:
            folder_id: The ID of the folder whose notes to list.
            fields: Optional iterable of field names to include in the response.
            page: Optional page number for pagination.
            limit: Optional number of items per page.
            order_by: Optional field name to order by.
            order_dir: Optional order direction ("ASC" or "DESC").
        Returns:
            PagedResults[JoplinNote]: A paginated list of Joplin notes within the folder.
        """
        effective_page = page if page is not None else DEFAULT_PAGE
        effective_limit = limit if limit is not None else DEFAULT_LIMIT
        params = self._build_pagination_params(
            fields=fields,
            page=effective_page,
            limit=effective_limit,
            order_by=order_by,
            order_dir=order_dir,
        )
        raw = self._request("GET", f"folders/{folder_id}/notes", params=params)
        items = [JoplinNote.model_validate(it) for it in raw.get("items", [])]
        return PagedResults[JoplinNote](
            items=items,
            has_more=bool(raw.get("has_more", False)),
            page=effective_page,
            limit=effective_limit,
        )
