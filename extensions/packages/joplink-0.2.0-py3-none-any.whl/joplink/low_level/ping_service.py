from __future__ import annotations

from .base import BaseService

"""Ping service facade."""

class PingService(BaseService):

    def ping(self) -> str:
        """Ping the Joplin server to check connectivity.
        Returns:
            str: The server's ping response.
        """
        # The endpoint returns plain text (not JSON), so propagate as str
        return str(self._request("GET", "ping"))

