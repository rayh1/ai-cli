from __future__ import annotations

from typing import Any, Dict, Iterable, Optional

from .base import BaseService
from ..models import JoplinNote, JoplinTag, PagedResults, DEFAULT_PAGE, DEFAULT_LIMIT

"""Notes service facade.

Returns typed `JoplinNote` models and a `SearchResults` container for
paginated endpoints.
"""


class NotesService(BaseService):
    def list_notes(
        self,
        *,
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
        order_by: Optional[str] = None,
        order_dir: Optional[str] = None,
        include_deleted: Optional[int] = None,
        include_conflicts: Optional[int] = None,
    ) -> PagedResults[JoplinNote]:
        """List notes with optional pagination and filtering.
        Args:
            fields: Optional iterable of field names to include in the response.
            page: Optional page number for pagination.
            limit: Optional number of items per page.
            order_by: Optional field name to order by.
            order_dir: Optional order direction ("ASC" or "DESC").
            include_deleted: If set to 1, include notes in the trash folder.
            include_conflicts: If set to 1, include conflict notes.
        Returns:
            PagedResults[JoplinNote]: A paginated list of Joplin notes.
        """
        effective_page = page if page is not None else DEFAULT_PAGE
        effective_limit = limit if limit is not None else DEFAULT_LIMIT
        params = self._build_pagination_params(
            fields=fields,
            page=effective_page,
            limit=effective_limit,
            order_by=order_by,
            order_dir=order_dir,
        )
        if include_deleted is not None:
            params["include_deleted"] = include_deleted
        if include_conflicts is not None:
            params["include_conflicts"] = include_conflicts
        raw = self._request("GET", "notes", params=params)
        items = [JoplinNote.model_validate(it) for it in raw.get("items", [])]
        return PagedResults[JoplinNote](
            items=items,
            has_more=bool(raw.get("has_more", False)),
            page=effective_page,
            limit=effective_limit,
        )

    def get_note(self, note_id: str, *, fields: Optional[Iterable[str]] = None) -> JoplinNote:
        """Get a single note by ID.
        Args:
            note_id: The ID of the note to retrieve.
            fields: Optional iterable of field names to include in the response.
        Returns:
            JoplinNote: The requested Joplin note.
        """
        params: Dict[str, Any] = {}
        if fields is not None:
            params["fields"] = ",".join(fields)
        raw = self._request("GET", f"notes/{note_id}", params=params)
        return JoplinNote.model_validate(raw)

    def create_note(self, data: Dict[str, Any]) -> JoplinNote:
        """Create a new note.
        Args:
            data: A dictionary containing note fields and values.
        Returns:
            JoplinNote: The created Joplin note.
        """
        raw = self._request("POST", "notes", json=data)
        return JoplinNote.model_validate(raw)

    def update_note(self, note_id: str, data: Dict[str, Any]) -> JoplinNote:
        """Update an existing note.
        Args:
            note_id: The ID of the note to update.
            data: A dictionary containing note fields and values.
        Returns:
            JoplinNote: The updated Joplin note.
        """
        raw = self._request("PUT", f"notes/{note_id}", json=data)
        return JoplinNote.model_validate(raw)

    def delete_note(self, note_id: str) -> Any:
        """Delete a note by ID.
        Args:
            note_id: The ID of the note to delete.
        Returns:
            Any: The response from the delete operation.
        """
        return self._request("DELETE", f"notes/{note_id}")

    def list_tags_for_note(
        self,
        note_id: str,
        *,
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> PagedResults[JoplinTag]:
        """List tags associated with a specific note.
        Args:
            note_id: The ID of the note whose tags to list.
            fields: Optional iterable of field names to include in the response.
            page: Optional page number for pagination.
            limit: Optional number of items per page.
        Returns:
            PagedResults[JoplinTag]: A paginated list of Joplin tags associated with the note.
        """
        effective_page = page if page is not None else DEFAULT_PAGE
        effective_limit = limit if limit is not None else DEFAULT_LIMIT
        params = self._build_pagination_params(
            fields=fields,
            page=effective_page,
            limit=effective_limit,
        )
        raw = self._request("GET", f"notes/{note_id}/tags", params=params)
        items = [JoplinTag.model_validate(it) for it in raw.get("items", [])]
        return PagedResults[JoplinTag](
            items=items,
            has_more=bool(raw.get("has_more", False)),
            page=effective_page,
            limit=effective_limit,
        )
