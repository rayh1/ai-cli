from __future__ import annotations

from typing import Any, Dict, Iterable, Optional

from .base import BaseService, JoplinServerError
from ..models import JoplinTag, JoplinNote, PagedResults, DEFAULT_PAGE, DEFAULT_LIMIT


"""Tags service facade."""


class TagsService(BaseService):
    def list_tags(
        self,
        *,
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
        order_by: Optional[str] = None,
        order_dir: Optional[str] = None,
    ) -> PagedResults[JoplinTag]:
        """List tags with optional pagination and sorting.
        Args:
            fields: Optional iterable of field names to include in the response.
            page: Optional page number for pagination.
            limit: Optional number of items per page.
            order_by: Optional field name to order by.
            order_dir: Optional order direction ("ASC" or "DESC").
        Returns:
            PagedResults[JoplinTag]: A paginated list of Joplin tags.
        """
        effective_page = page if page is not None else DEFAULT_PAGE
        effective_limit = limit if limit is not None else DEFAULT_LIMIT
        params = self._build_pagination_params(
            fields=fields,
            page=effective_page,
            limit=effective_limit,
            order_by=order_by,
            order_dir=order_dir,
        )
        raw = self._request("GET", "tags", params=params)
        items = [JoplinTag.model_validate(it) for it in raw.get("items", [])]
        return PagedResults[JoplinTag](
            items=items,
            has_more=bool(raw.get("has_more", False)),
            page=effective_page,
            limit=effective_limit,
        )

    def get_tag(self, tag_id: str, *, fields: Optional[Iterable[str]] = None) -> JoplinTag:
        """Get a single tag by ID.
        Args:
            tag_id: The ID of the tag to retrieve.
            fields: Optional iterable of field names to include in the response.
        Returns:
            JoplinTag: The requested Joplin tag.
        """
        params = self._build_pagination_params(fields=fields)
        raw = self._request("GET", f"tags/{tag_id}", params=params)
        return JoplinTag.model_validate(raw)

    def create_tag(self, data: Dict[str, Any]) -> JoplinTag:
        """Create a tag.

        This method attempts to be idempotent: if the server returns a 500
        error indicating the tag already exists, the method will try to list
        tags by title and return the existing resource instead of raising an
        error. This behavior is defensive and intended to make create
        operations safe to call when the client can't guarantee the
        tag doesn't already exist (for example, during retries).
        """
        try:
            raw = self._request("POST", "tags", json=data)
        except JoplinServerError as exc:
            # When a tag with the same name already exists, Joplin may return a 500
            # with an error message indicating the duplicate. In that case, try to
            # fetch the existing tag by title and return it instead of failing.
            message = str(exc).lower()
            # Only treat server 500 errors that include a known phrase as a "duplicate"
            # and try to return the existing tag instead of raising. We additionally log
            # when the duplicate-resolve path is taken for observability.
            if "already exists" in message and data.get("title"):
                title = data["title"]
                # Try to locate an existing tag with the same title
                import logging
                logger = logging.getLogger(__name__)
                logger.info(
                    "Duplicate tag create detected; falling back to listing tags to find existing id",
                    extra={"title": title},
                )
                tags_page = self.list_tags(fields=["id", "title"])
                for t in tags_page.items:
                    if t.title == title:
                        return t
            # Re-raise the original exception if we can't resolve it
            raise
        return JoplinTag.model_validate(raw)

    def update_tag(self, tag_id: str, data: Dict[str, Any]) -> JoplinTag:
        """Update an existing tag.
        Args:
            tag_id: The ID of the tag to update.
            data: A dictionary containing tag fields and values.
        Returns:
            JoplinTag: The updated Joplin tag.
        """
        raw = self._request("PUT", f"tags/{tag_id}", json=data)
        return JoplinTag.model_validate(raw)

    def delete_tag(self, tag_id: str) -> Any:
        """Delete a tag by ID.
        Args:
            tag_id: The ID of the tag to delete.
        Returns:
            Any: The response from the delete operation.
        """
        return self._request("DELETE", f"tags/{tag_id}")

    def list_notes_for_tag(
        self,
        tag_id: str,
        *,
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> PagedResults[JoplinNote]:
        """List notes associated with a specific tag.
        Args:
            tag_id: The ID of the tag whose notes to list.
            fields: Optional iterable of field names to include in the response.
            page: Optional page number for pagination.
            limit: Optional number of items per page.
        Returns:
            PagedResults[JoplinNote]: A paginated list of Joplin notes associated with the tag.
        """
        effective_page = page if page is not None else DEFAULT_PAGE
        effective_limit = limit if limit is not None else DEFAULT_LIMIT
        params = self._build_pagination_params(
            fields=fields,
            page=effective_page,
            limit=effective_limit,
        )
        raw = self._request("GET", f"tags/{tag_id}/notes", params=params)
        items = [JoplinNote.model_validate(it) for it in raw.get("items", [])]
        return PagedResults[JoplinNote](
            items=items,
            has_more=bool(raw.get("has_more", False)),
            page=effective_page,
            limit=effective_limit,
        )

    def add_tag_to_note(self, tag_id: str, note_id: str) -> Dict[str, Any]:
        """Add a tag to a note.
        Args:
            tag_id: The ID of the tag to add.
            note_id: The ID of the note to which the tag will be added.
        Returns:
            Dict[str, Any]: The response from the add operation.
        """
        return self._request("POST", f"tags/{tag_id}/notes", json={"id": note_id})

    def remove_tag_from_note(self, tag_id: str, note_id: str) -> Any:
        """Remove a tag from a note.
        Args:
            tag_id: The ID of the tag to remove.
            note_id: The ID of the note from which the tag will be removed.
        Returns:
            Any: The response from the remove operation.
        """
        return self._request("DELETE", f"tags/{tag_id}/notes/{note_id}")
