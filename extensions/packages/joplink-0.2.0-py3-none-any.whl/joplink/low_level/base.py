from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Dict, Optional, Iterable

import httpx
import logging
import json as _json


class JoplinClientError(Exception):
    """Base error for Joplin client failures."""


class JoplinConfigError(JoplinClientError):
    """Raised when required configuration (such as token) is missing or invalid."""


class JoplinRequestError(JoplinClientError):
    """Raised when an httpx request fails (connectivity issues, DNS, etc.)."""


class JoplinTimeoutError(JoplinClientError):
    """Raised when a request times out."""


class JoplinAuthError(JoplinClientError):
    """Raised for authentication/authorization errors (401/403)."""


class JoplinNotFoundError(JoplinClientError):
    """Raised for 404 Not Found responses."""


class JoplinPathError(JoplinClientError):
    """Raised when a path has invalid format or escape sequences."""


class JoplinServerError(JoplinClientError):
    """Raised for 5xx server error responses."""


@dataclass
class JoplinConfig:
    """Configuration for the Joplin Data API client.

    This dataclass holds configuration values used to communicate with a
    Joplin Data API instance. It supports convenient overrides via
    environment variables and performs basic validation on construction.

    Attributes:
        base_url: Base URL of the Joplin server. Defaults to
            ``http://127.0.0.1:41184``. Can be overridden with the
            ``JOPLIN_BASE_URL`` environment variable. Trailing slashes are
            removed automatically.
        token: API token used to authenticate requests to the Joplin Data
            API. If not provided when the dataclass is instantiated the
            ``JOPLIN_TOKEN`` environment variable will be used. A
            :class:`JoplinConfigError` is raised if a token cannot be found.
        timeout: Request timeout (in seconds). Defaults to ``10.0`` and can be
            overridden with the ``JOPLIN_TIMEOUT`` environment variable. If
            the environment value is not a number a :class:`JoplinConfigError`
            will be raised.
    """
    base_url: str = "http://127.0.0.1:41184"
    token: Optional[str] = None
    timeout: float = 10.0

    def __post_init__(self) -> None:
        env_base = os.getenv("JOPLIN_BASE_URL")
        if env_base:
            self.base_url = env_base.rstrip("/")
        else:
            self.base_url = self.base_url.rstrip("/")

        if self.token is None:
            self.token = os.getenv("JOPLIN_TOKEN")

        # Optional ENV override for timeout
        env_timeout = os.getenv("JOPLIN_TIMEOUT")
        if env_timeout:
            try:
                self.timeout = float(env_timeout)
            except ValueError as exc:  # pragma: no cover - invalid env value
                raise JoplinConfigError("JOPLIN_TIMEOUT must be a number") from exc

        if not self.token:
            raise JoplinConfigError("JOPLIN_TOKEN is required for Joplin Data API access")


LOG_FIELDS = {
    "event": "event",
    "method": "method",
    "url": "url",
    "status": "status",
    "status_code": "status_code",
    "message": "message",
}


@dataclass
class BaseService:
    config: JoplinConfig

    def _build_url(self, *parts: str) -> str:
        """Create a full URL by joining base URL and path parts.

        The function ensures there are no duplicate slashes and
        that trailing slashes are removed from the base URL.
        """
        path = "/".join(p.strip("/") for p in parts if p)
        return f"{self.config.base_url}/{path}"

    def _request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Internal convenience for performing HTTP calls to Joplin.

        This wrapper automatically adds the required `token` query
        parameter, enforces configurable timeouts, and maps HTTP
        errors into typed exceptions for the client caller.
        """
        params = params or {}
        # always include token — fail fast if no token is present
        if not self.config.token:
            raise JoplinConfigError("JOPLIN_TOKEN is required for Joplin Data API access")
        params = {**params, "token": self.config.token}

        url = self._build_url(path)
        logger = logging.getLogger(__name__)
        logger.debug(
            _json.dumps({LOG_FIELDS["event"]: "joplin_request", LOG_FIELDS["method"]: method, LOG_FIELDS["url"]: url, "params": params})
        )
        try:
            resp = httpx.request(method, url, params=params, json=json, timeout=self.config.timeout)
        except httpx.TimeoutException as exc:  # pragma: no cover - timeout path
            raise JoplinTimeoutError(f"Joplin API call timed out: {exc}") from exc
        except httpx.RequestError as exc:  # pragma: no cover - network failure path
            raise JoplinRequestError(f"Failed to call Joplin API: {exc}") from exc

        if resp.status_code >= 400:
            try:
                data = resp.json()
                # Only use JSON body if it's a mapping with an 'error' key
                if isinstance(data, dict):
                    message = data.get("error") or str(data)
                else:
                    message = resp.text
            except Exception:  # pragma: no cover - non-JSON error bodies
                message = resp.text
            logger.warning(
                _json.dumps(
                    {
                        LOG_FIELDS["event"]: "joplin_response_error",
                        LOG_FIELDS["method"]: method,
                        LOG_FIELDS["url"]: url,
                        LOG_FIELDS["message"]: message,
                        LOG_FIELDS["status_code"]: resp.status_code,
                    }
                )
            )
            if resp.status_code in (401, 403):
                raise JoplinAuthError(f"Joplin API auth error {resp.status_code}: {message}")
            if resp.status_code == 404:
                raise JoplinNotFoundError(f"Joplin API not found: {message}")
            if resp.status_code >= 500:
                raise JoplinServerError(f"Joplin Server error {resp.status_code}: {message}")
            raise JoplinClientError(f"Joplin API error {resp.status_code}: {message}")

        content_type = resp.headers.get("content-type", "")
        logger.debug(
            _json.dumps({LOG_FIELDS["event"]: "joplin_response", LOG_FIELDS["method"]: method, LOG_FIELDS["url"]: url, LOG_FIELDS["status"]: resp.status_code})
        )
        if "application/json" in content_type:
            return resp.json()
        return resp.text

    def _build_pagination_params(
        self,
        *,
        fields: Optional[Iterable[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
        order_by: Optional[str] = None,
        order_dir: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Build a standard set of pagination / list query params for endpoints.

        This helper keeps the services DRY when they need to construct list
        query parameters and ensures they all follow the same rules.
        """
        params: Dict[str, Any] = {}
        if fields is not None:
            params["fields"] = ",".join(fields)
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit
        if order_by is not None:
            params["order_by"] = order_by
        if order_dir is not None:
            params["order_dir"] = order_dir
        return params
