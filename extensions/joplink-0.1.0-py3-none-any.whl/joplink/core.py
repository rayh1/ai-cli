"""
Core functionality for Joplink MCP Server.

Contains configuration, HTTP clients, and helper functions shared across tools.
"""

import os
import tempfile
import uuid
import time
import logging
import sys
from typing import Any, Dict, List, Optional
from urllib.parse import urlencode
import httpx

# Version for User-Agent header (F94)
__version__ = "0.1.0"

# Configure structured logging (F8)
logger = logging.getLogger("joplink")
logger.setLevel(logging.INFO)

# Add console handler with structured format
handler = logging.StreamHandler(sys.stderr)
handler.setLevel(logging.INFO)
formatter = logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
handler.setFormatter(formatter)
logger.addHandler(handler)


def redact_token(text: str, token: str) -> str:
    """Redact token from text for logging (F8)."""
    if not token:
        return text
    return text.replace(token, "***REDACTED***")


# Configuration
class ConfigError(Exception):
    """Configuration validation error (F97)."""
    pass


class Config:
    def __init__(self):
        self.base_url = os.getenv("JOPLIN_BASE_URL", "http://127.0.0.1:41184").rstrip("/")
        self.token = os.getenv("JOPLIN_TOKEN", "")
        
        # Validate timeout
        try:
            self.timeout_ms = int(os.getenv("JOPLIN_TIMEOUT_MS", "10000"))
        except ValueError as e:
            raise ConfigError(f"JOPLIN_TIMEOUT_MS must be integer: {e}")
        
        # Validate max_limit
        try:
            self.max_limit = int(os.getenv("JOPLIN_MAX_LIMIT", "100"))
        except ValueError as e:
            raise ConfigError(f"JOPLIN_MAX_LIMIT must be integer: {e}")
        
        self.download_dir = os.path.abspath(os.getenv("JOPLIN_DOWNLOAD_DIR", tempfile.gettempdir()))
        self.enable_auth_flow = os.getenv("ENABLE_AUTH_FLOW", "").lower() == "true"
        
        # Validate max_upload_bytes
        try:
            self.max_upload_bytes = int(os.getenv("JOPLIN_MAX_UPLOAD_BYTES", str(50 * 1024 * 1024)))
        except ValueError as e:
            raise ConfigError(f"JOPLIN_MAX_UPLOAD_BYTES must be integer: {e}")
        
        # Validate token if auth flow is disabled (F97: use ConfigError for config issues)
        if not self.enable_auth_flow and not self.token:
            raise ConfigError("JOPLIN_TOKEN is required when ENABLE_AUTH_FLOW is not enabled")

        # Ensure download directory exists
        os.makedirs(self.download_dir, exist_ok=True)


# HTTP Clients
class JoplinClient:
    def __init__(self, config: Config):
        self.config = config
        self.client = httpx.Client(timeout=config.timeout_ms / 1000.0)
    
    def _add_token(self, url: str, params: Optional[Dict[str, Any]] = None) -> str:
        """Add token to URL as query parameter"""
        if not self.config.token:
            raise ValueError("Missing token")
        
        params = params or {}
        params["token"] = self.config.token
        return f"{url}?{urlencode(params)}"
    
    def _handle_error(self, response: httpx.Response, endpoint: str, request_id: str) -> Dict[str, Any]:
        """Transform HTTP errors into standard error format"""
        try:
            error_data = response.json()
            error_msg = error_data.get("error", response.text)
        except Exception:
            error_msg = response.text or f"HTTP {response.status_code}"
        
        return {
            "error": error_msg,
            "status": response.status_code,
            "endpoint": endpoint,
            "requestId": request_id
        }
    
    def get(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """GET request to Joplin API"""
        request_id = str(uuid.uuid4())
        url = f"{self.config.base_url}{endpoint}"
        
        try:
            full_url = self._add_token(url, params)
            response = self.client.get(full_url)
            
            if response.status_code >= 400:
                return self._handle_error(response, endpoint, request_id)
            
            return response.json()
        except httpx.TimeoutException:
            return {
                "error": "Upstream timeout",
                "status": 504,
                "endpoint": endpoint,
                "requestId": request_id
            }
        except Exception as e:
            return {
                "error": str(e),
                "status": 500,
                "endpoint": endpoint,
                "requestId": request_id
            }
    
    def post(self, endpoint: str, data: Dict[str, Any], params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """POST request to Joplin API"""
        request_id = str(uuid.uuid4())
        url = f"{self.config.base_url}{endpoint}"
        
        try:
            full_url = self._add_token(url, params)
            response = self.client.post(full_url, json=data)
            
            if response.status_code >= 400:
                return self._handle_error(response, endpoint, request_id)
            
            return response.json()
        except httpx.TimeoutException:
            return {
                "error": "Upstream timeout",
                "status": 504,
                "endpoint": endpoint,
                "requestId": request_id
            }
        except Exception as e:
            return {
                "error": str(e),
                "status": 500,
                "endpoint": endpoint,
                "requestId": request_id
            }
    
    def put(self, endpoint: str, data: Dict[str, Any], params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """PUT request to Joplin API"""
        request_id = str(uuid.uuid4())
        url = f"{self.config.base_url}{endpoint}"
        
        try:
            full_url = self._add_token(url, params)
            response = self.client.put(full_url, json=data)
            
            if response.status_code >= 400:
                return self._handle_error(response, endpoint, request_id)
            
            return response.json()
        except httpx.TimeoutException:
            return {
                "error": "Upstream timeout",
                "status": 504,
                "endpoint": endpoint,
                "requestId": request_id
            }
        except Exception as e:
            return {
                "error": str(e),
                "status": 500,
                "endpoint": endpoint,
                "requestId": request_id
            }
    
    def delete(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """DELETE request to Joplin API"""
        request_id = str(uuid.uuid4())
        url = f"{self.config.base_url}{endpoint}"
        
        try:
            full_url = self._add_token(url, params)
            response = self.client.delete(full_url)
            
            if response.status_code >= 400:
                return self._handle_error(response, endpoint, request_id)
            
            # DELETE may return empty response
            if response.text:
                return response.json()
            return {"ok": True}
        except httpx.TimeoutException:
            return {
                "error": "Upstream timeout",
                "status": 504,
                "endpoint": endpoint,
                "requestId": request_id
            }
        except Exception as e:
            return {
                "error": str(e),
                "status": 500,
                "endpoint": endpoint,
                "requestId": request_id
            }


class AsyncJoplinClient:
    """Async HTTP client wrapper for Joplin API with unified error formatting (F5, F63)."""

    _ALLOW_MISSING_TOKEN_ENDPOINTS = {"/ping", "/auth", "/auth/check"}

    def __init__(self, config: Config):
        self.config = config
        # Keep simple numeric timeout for now; can expand to granular timeouts later
        # Add User-Agent header (F94)
        headers = {"User-Agent": f"joplink/{__version__}"}
        self.client = httpx.AsyncClient(
            timeout=config.timeout_ms / 1000.0,
            headers=headers
        )

    def _build_url(self, endpoint: str) -> str:
        return f"{self.config.base_url}{endpoint}"

    def _error(self, *, endpoint: str, status: int, message: str, request_id: Optional[str] = None, kind: Optional[str] = None, duration_ms: Optional[int] = None) -> Dict[str, Any]:
        return {
            "error": message,
            "status": status,
            "endpoint": endpoint,
            "requestId": request_id or str(uuid.uuid4()),
            **({"kind": kind} if kind else {}),
            **({"duration_ms": duration_ms} if duration_ms is not None else {}),
        }

    def _add_token_params(self, params: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        params = params.copy() if params else {}
        if self.config.token:
            params["token"] = self.config.token
        return params

    async def _request(
        self,
        method: str,
        endpoint: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json_body: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
        expect_json: bool = True,
        allow_missing_token: bool = False,
    ) -> Any:
        request_id = str(uuid.uuid4())
        url = self._build_url(endpoint)

        # Log request start (F8)
        logger.info(f"Request start: {method} {endpoint} [requestId={request_id}]")

        # Missing token -> structured 401 (F63); allow /ping without token
        allow_without_token = allow_missing_token or endpoint in self._ALLOW_MISSING_TOKEN_ENDPOINTS
        if not self.config.token and not allow_without_token:
            logger.warning(f"Missing token for {endpoint} [requestId={request_id}]")
            return self._error(endpoint=endpoint, status=401, message="Missing token", request_id=request_id, kind="auth")

        try:
            start = time.time()
            resp = await self.client.request(
                method,
                url,
                params=self._add_token_params(params),
                json=json_body,
                data=data,
                files=files,
            )
            duration_ms = int((time.time() - start) * 1000)
            
            # Log response (F8, F78)
            logger.info(f"Request complete: {method} {endpoint} status={resp.status_code} duration={duration_ms}ms [requestId={request_id}]")

            if resp.status_code >= 400:
                # Attempt to decode error
                try:
                    payload = resp.json()
                    msg = payload.get("error", resp.text)
                except Exception:
                    msg = resp.text or f"HTTP {resp.status_code}"
                return self._error(endpoint=endpoint, status=resp.status_code, message=msg, request_id=request_id, kind="http_error", duration_ms=duration_ms)

            # Successful response handling
            if not expect_json:
                return {
                    "content": resp.content,
                    "headers": dict(resp.headers),
                    "status": resp.status_code,
                    "endpoint": endpoint,
                    "requestId": request_id,
                    "duration_ms": duration_ms,
                }

            if not resp.content or resp.status_code == 204:
                # Align with previous behaviour: DELETE with empty body -> {"ok": True}
                if method.upper() == "DELETE":
                    return {"ok": True}
                return {}

            content_type = resp.headers.get("content-type", "")
            if "application/json" in content_type:
                try:
                    return resp.json()
                except ValueError:
                    # Fallback to empty dict / ok for DELETE, else return text
                    if method.upper() == "DELETE":
                        return {"ok": True}
                    return {}

            # Non-JSON response; return text payload
            text = resp.text
            if text == "" and method.upper() == "DELETE":
                return {"ok": True}
            return text
        except httpx.TimeoutException:
            logger.error(f"Request timeout: {method} {endpoint} [requestId={request_id}]")
            return self._error(endpoint=endpoint, status=504, message="Upstream timeout", request_id=request_id, kind="timeout")
        except Exception as e:
            logger.error(f"Request exception: {method} {endpoint} error={str(e)} [requestId={request_id}]")
            return self._error(endpoint=endpoint, status=500, message=str(e), request_id=request_id, kind="exception")

    async def get(
        self,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        *,
        expect_json: bool = True,
        allow_missing_token: bool = False,
    ) -> Any:
        return await self._request("GET", endpoint, params=params, expect_json=expect_json, allow_missing_token=allow_missing_token)

    async def post(
        self,
        endpoint: str,
        data: Dict[str, Any],
        params: Optional[Dict[str, Any]] = None,
        *,
        allow_missing_token: bool = False,
    ) -> Any:
        return await self._request("POST", endpoint, params=params, json_body=data, allow_missing_token=allow_missing_token)

    async def post_form(
        self,
        endpoint: str,
        form_data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        return await self._request("POST", endpoint, params=params, data=form_data, files=files)

    async def put(
        self,
        endpoint: str,
        data: Dict[str, Any],
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        return await self._request("PUT", endpoint, params=params, json_body=data)

    async def delete(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Any:
        return await self._request("DELETE", endpoint, params=params)


# Default field constants (F11)
DEFAULT_NOTE_FIELDS = "id,parent_id,title,updated_time"
DEFAULT_FOLDER_FIELDS = "id,parent_id,title,updated_time"
DEFAULT_TAG_FIELDS = "id,title,updated_time"
DEFAULT_RESOURCE_FIELDS = "id,title,mime,filename,size,updated_time"


# Helper functions
def encode_cursor(page: int) -> str:
    """Encode page number to cursor string"""
    return str(page)


def decode_cursor(cursor: Optional[str]) -> Any:
    """Decode cursor string to page number (1-based).
    
    Returns:
        int: Valid page number (>= 1)
        dict: Error response if cursor is invalid (F10)
    """
    if not cursor:
        return 1
    try:
        page = int(cursor)
        if page < 1:
            return error_response("/cursor", 400, "cursor must be positive")
        return page
    except ValueError:
        return error_response("/cursor", 400, "cursor must be a valid integer")


def build_paginated_response(items: List[Any], has_more: bool, current_page: int) -> Dict[str, Any]:
    """Build standardized paginated response"""
    result = {
        "items": items,
        "has_more": has_more
    }
    if has_more:
        result["next_cursor"] = encode_cursor(current_page + 1)
    return result


def error_response(endpoint: str, status: int, message: str) -> Dict[str, Any]:
    """Create a standardized error response for tool-level validation (F33)."""
    return {
        "error": message,
        "status": status,
        "endpoint": endpoint,
        "requestId": str(uuid.uuid4()),
    }


def ensure_limit(endpoint: str, limit: Optional[Any], max_limit: int = 100) -> Any:
    """Validate and normalize limit parameter (F86).
    
    Args:
        endpoint: API endpoint for error reporting
        limit: Limit value to validate
        max_limit: Maximum allowed limit (default: 100)
    
    Returns:
        int: Valid limit value
        dict: Error response if limit is invalid
    """
    if limit is None:
        return 50
    # Type check for non-integer inputs (F86)
    # Reject float explicitly (even though int(3.14) works, it's lossy)
    if isinstance(limit, float):
        return error_response(endpoint, 422, "limit must be integer, not float")
    if not isinstance(limit, int):
        try:
            value = int(limit)
        except (TypeError, ValueError):
            return error_response(endpoint, 422, "limit must be integer")
    else:
        value = limit
    
    if value <= 0:
        return error_response(endpoint, 400, "limit must be positive")
    if value > max_limit:
        return error_response(endpoint, 400, f"limit exceeds maximum of {max_limit}")
    return value


def serialize_fields(fields: Optional[List[str]], default: str) -> str:
    """Serialize list of fields to comma-separated string with default fallback."""
    if not fields:
        return default
    return ",".join(fields)


def ensure_safe_path(base_dir: str, filename: str) -> str:
    """Ensure generated filename stays within the configured base directory."""
    safe_name = os.path.basename(filename)
    candidate = os.path.abspath(os.path.join(base_dir, safe_name))
    base = os.path.abspath(base_dir)
    if os.path.commonpath([candidate, base]) != base:
        raise ValueError("Resolved path escapes download directory")
    return candidate


def validate_todo_due(todo_due: Optional[int]) -> Any:
    """Validate todo_due timestamp (F44).
    
    Args:
        todo_due: Unix timestamp in milliseconds
        
    Returns:
        int: Valid timestamp
        dict: Error response if invalid
        None: If input is None
    """
    if todo_due is None:
        return None
    
    if not isinstance(todo_due, int):
        return error_response("/validation", 422, "todo_due must be integer")
    
    # Reasonable range: between 1970 and year 2100
    # 0 = 1970-01-01, 4102444800000 = 2100-01-01
    if todo_due < 0 or todo_due > 4102444800000:
        return error_response("/validation", 400, "todo_due out of valid range")
    
    return todo_due
