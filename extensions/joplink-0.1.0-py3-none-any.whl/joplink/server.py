#!/usr/bin/env python3
"""
Joplink MCP Server
"""

from typing import Any, Dict, List, Optional, Literal
import json
import mimetypes
import os
from fastmcp import FastMCP

# Import all core functionality from the core module (F65)
from .core import (
    Config,
    JoplinClient,
    AsyncJoplinClient,
    encode_cursor,
    decode_cursor,
    build_paginated_response,
    error_response,
    ensure_limit,
    serialize_fields,
    ensure_safe_path,
    validate_todo_due,
    DEFAULT_NOTE_FIELDS,
    DEFAULT_FOLDER_FIELDS,
    DEFAULT_TAG_FIELDS,
    DEFAULT_RESOURCE_FIELDS,
    __version__,
    logger
)

# Initialize FastMCP server
mcp = FastMCP("joplink")

# Create global instances
config = Config()
joplin = JoplinClient(config)
ajoplin = AsyncJoplinClient(config)

# Notes Tools

@mcp.tool()
async def notes_list(
    fields: Optional[List[str]] = None,
    limit: Optional[int] = None,
    order_by: Optional[str] = None,
    order_dir: Optional[Literal["ASC", "DESC"]] = None,
    cursor: Optional[str] = None,
    folder_id: Optional[str] = None
) -> Dict[str, Any]:
    """List notes with pagination and filtering
    
    Args:
        fields: List of fields to return (default: id, parent_id, title, updated_time)
        limit: Maximum number of items to return (default: 50, max: JOPLIN_MAX_LIMIT)
        order_by: Field to order by (default: updated_time)
        order_dir: Order direction ASC or DESC (default: DESC)
        cursor: Pagination cursor (page number as string)
        folder_id: Filter by parent folder ID
        
    Returns:
        Paginated response with items, has_more, and optional next_cursor
    """
    # Validate limit (F86)
    validated_limit = ensure_limit("/notes", limit, config.max_limit)
    if isinstance(validated_limit, dict) and "error" in validated_limit:
        return validated_limit
    
    # Validate cursor (F10)
    page = decode_cursor(cursor)
    if isinstance(page, dict) and "error" in page:
        return page
    
    # Build params
    params = {
        "limit": validated_limit,
        "order_by": order_by or "updated_time",
        "order_dir": order_dir or "DESC",
        "page": page
    }
    
    # Add fields
    if fields:
        params["fields"] = ",".join(fields)
    else:
        params["fields"] = DEFAULT_NOTE_FIELDS
    
    # Add folder filter
    if folder_id:
        params["parent_id"] = folder_id
    
    # Make request
    response = await ajoplin.get("/notes", params)
    
    # Check for error
    if "error" in response:
        return response
    
    # Build paginated response
    items = response.get("items", [])
    has_more = response.get("has_more", False)
    current_page = params["page"]
    
    return build_paginated_response(items, has_more, current_page)


@mcp.tool()
async def notes_get(note_id: str, fields: Optional[List[str]] = None) -> Dict[str, Any]:
    """Get a specific note by ID
    
    Args:
        note_id: The ID of the note to retrieve
        fields: List of fields to return (default: id, parent_id, title, updated_time)
        
    Returns:
        Note object or error
    """
    params = {}
    
    if fields:
        params["fields"] = ",".join(fields)
    else:
        params["fields"] = DEFAULT_NOTE_FIELDS
    
    return await ajoplin.get(f"/notes/{note_id}", params)


@mcp.tool()
async def notes_create(
    title: str,
    body: Optional[str] = None,
    body_html: Optional[str] = None,
    parent_id: Optional[str] = None,
    is_todo: Optional[bool] = None,
    todo_due: Optional[int] = None
) -> Dict[str, Any]:
    """Create a new note
    
    Args:
        title: Note title
        body: Note body in Markdown format
        body_html: Note body in HTML format (alternative to body)
        parent_id: Parent folder ID
        is_todo: Whether this is a to-do item
        todo_due: Due date for to-do (epoch milliseconds)
        
    Returns:
        Created note object or error
    """
    data: Dict[str, Any] = {"title": title}
    
    # body and body_html are mutually exclusive (F12)
    if body is not None and body_html is not None:
        return error_response("/notes", 400, "Provide either body or body_html, not both")

    # Validate todo_due if provided (F44)
    validated_due = validate_todo_due(todo_due)
    if isinstance(validated_due, dict) and "error" in validated_due:
        return validated_due

    if body is not None:
        data["body"] = body
    if body_html is not None:
        data["body_html"] = body_html
    if parent_id is not None:
        data["parent_id"] = parent_id
    if is_todo is not None:
        data["is_todo"] = 1 if is_todo else 0
    if validated_due is not None:
        data["todo_due"] = validated_due
    
    return await ajoplin.post("/notes", data)


@mcp.tool()
async def notes_update(
    note_id: str,
    title: Optional[str] = None,
    body: Optional[str] = None,
    body_html: Optional[str] = None,
    parent_id: Optional[str] = None,
    is_todo: Optional[bool] = None,
    todo_due: Optional[int] = None
) -> Dict[str, Any]:
    """Update an existing note (partial update)
    
    Args:
        note_id: The ID of the note to update
        title: New title
        body: New body in Markdown format
        body_html: New body in HTML format
        parent_id: New parent folder ID
        is_todo: Whether this is a to-do item
        todo_due: Due date for to-do (epoch milliseconds)
        
    Returns:
        Updated note object or error
    """
    data: Dict[str, Any] = {}
    
    # body and body_html are mutually exclusive (F12)
    if body is not None and body_html is not None:
        return error_response(f"/notes/{note_id}", 400, "Provide either body or body_html, not both")

    # Validate todo_due if provided (F44)
    validated_due = validate_todo_due(todo_due)
    if isinstance(validated_due, dict) and "error" in validated_due:
        return validated_due

    if title is not None:
        data["title"] = title
    if body is not None:
        data["body"] = body
    if body_html is not None:
        data["body_html"] = body_html
    if parent_id is not None:
        data["parent_id"] = parent_id
    if is_todo is not None:
        data["is_todo"] = 1 if is_todo else 0
    if validated_due is not None:
        data["todo_due"] = validated_due
    
    if not data:
        return error_response(f"/notes/{note_id}", 400, "No fields provided for update")

    return await ajoplin.put(f"/notes/{note_id}", data)


@mcp.tool()
async def notes_delete(note_id: str, permanent: bool = False) -> Dict[str, Any]:
    """Delete a note
    
    Args:
        note_id: The ID of the note to delete
        permanent: If True, permanently delete; if False, soft delete (default: False)
        
    Returns:
        Success confirmation or error
    """
    params = {}
    if permanent:
        params["permanent"] = "1"
    
    return await ajoplin.delete(f"/notes/{note_id}", params)


@mcp.tool()
async def notes_tags_list(note_id: str, fields: Optional[List[str]] = None) -> Dict[str, Any]:
    """List all tags associated with a note
    
    Args:
        note_id: The ID of the note
        fields: List of fields to return (default: id, title)
        
    Returns:
        List of tag objects or error
    """
    params = {}
    
    if fields:
        params["fields"] = ",".join(fields)
    else:
        params["fields"] = "id,title"
    
    response = await ajoplin.get(f"/notes/{note_id}/tags", params)
    
    # The response should be a dict with items array
    if "error" not in response and "items" in response:
        return response
    elif "error" not in response:
        # If it's already an array, wrap it
        return {"items": response if isinstance(response, list) else [response]}
    
    return response


# Tag Tools


@mcp.tool()
async def tags_list(
    fields: Optional[List[str]] = None,
    limit: Optional[Any] = None,
    order_by: Optional[str] = None,
    order_dir: Optional[Literal["ASC", "DESC"]] = None,
    cursor: Optional[str] = None,
) -> Dict[str, Any]:
    """List tags with pagination support."""

    normalized_limit = ensure_limit("/tags", limit, config.max_limit)
    if isinstance(normalized_limit, dict) and normalized_limit.get("error"):
        return normalized_limit

    params = {
        "limit": normalized_limit,
        "order_by": order_by or "title",
        "order_dir": order_dir or "ASC",
        "page": decode_cursor(cursor),
        "fields": serialize_fields(fields, DEFAULT_TAG_FIELDS),
    }

    response = await ajoplin.get("/tags", params)
    if "error" in response:
        return response

    items = response.get("items", [])
    has_more = response.get("has_more", False)
    return build_paginated_response(items, has_more, params["page"])


@mcp.tool()
async def tags_create(title: str) -> Dict[str, Any]:
    """Create a new tag."""

    if not title or not title.strip():
        return error_response("/tags", 422, "title is required")

    payload = {"title": title.strip()}
    return await ajoplin.post("/tags", payload)


@mcp.tool()
async def tags_add_to_note(
    note_id: str,
    tag_id: Optional[str] = None,
    tag_title: Optional[str] = None,
) -> Dict[str, Any]:
    """Associate a tag with a note, creating the tag if necessary."""

    if not note_id:
        return error_response("/tags/notes", 422, "note_id is required")

    if not tag_id and not tag_title:
        return error_response("/tags/notes", 422, "Provide either tag_id or tag_title")

    resolved_tag: Optional[Dict[str, Any]] = None
    resolved_tag_id = tag_id

    if not resolved_tag_id and tag_title:
        create_response = await ajoplin.post("/tags", {"title": tag_title})
        if "error" in create_response:
            return create_response

        resolved_tag = create_response
        resolved_tag_id = create_response.get("id")
        if not resolved_tag_id:
            return error_response("/tags", 500, "Failed to resolve created tag id")

    link_response = await ajoplin.post(f"/tags/{resolved_tag_id}/notes", {"id": note_id})
    if "error" in link_response:
        return link_response

    if resolved_tag is None:
        tag_response = await ajoplin.get(f"/tags/{resolved_tag_id}")
        if "error" in tag_response:
            return {"ok": True, "tag": {"id": resolved_tag_id}}
        resolved_tag = tag_response

    return {"ok": True, "tag": resolved_tag}


@mcp.tool()
async def tags_remove_from_note(tag_id: str, note_id: str) -> Dict[str, Any]:
    """Remove a tag association from a note."""

    if not tag_id or not note_id:
        return error_response("/tags/notes", 422, "tag_id and note_id are required")

    response = await ajoplin.delete(f"/tags/{tag_id}/notes/{note_id}")
    if "error" in response:
        return response
    return {"ok": True}


# Folder Tools


@mcp.tool()
async def folders_list_tree(fields: Optional[List[str]] = None) -> Any:
    """Return the folder hierarchy as a tree."""

    params = {
        "fields": serialize_fields(fields, DEFAULT_FOLDER_FIELDS),
        "as_tree": 1,
    }
    return await ajoplin.get("/folders", params)


@mcp.tool()
async def folders_get(folder_id: str, fields: Optional[List[str]] = None) -> Dict[str, Any]:
    """Fetch a folder by id."""

    if not folder_id:
        return error_response("/folders", 422, "folder_id is required")

    params = {"fields": serialize_fields(fields, DEFAULT_FOLDER_FIELDS)}
    return await ajoplin.get(f"/folders/{folder_id}", params)


@mcp.tool()
async def folders_create(title: str, parent_id: Optional[str] = None) -> Dict[str, Any]:
    """Create a folder (notebook)."""

    if not title or not title.strip():
        return error_response("/folders", 422, "title is required")

    payload: Dict[str, Any] = {"title": title.strip()}
    if parent_id:
        payload["parent_id"] = parent_id
    return await ajoplin.post("/folders", payload)


@mcp.tool()
async def folders_update(folder_id: str, title: Optional[str] = None, parent_id: Optional[str] = None) -> Dict[str, Any]:
    """Update a folder."""

    if not folder_id:
        return error_response("/folders", 422, "folder_id is required")

    payload: Dict[str, Any] = {}
    if title is not None:
        if not title.strip():
            return error_response(f"/folders/{folder_id}", 422, "title cannot be empty")
        payload["title"] = title.strip()
    if parent_id is not None:
        payload["parent_id"] = parent_id

    if not payload:
        return error_response(f"/folders/{folder_id}", 400, "No fields provided for update")

    return await ajoplin.put(f"/folders/{folder_id}", payload)


@mcp.tool()
async def folders_delete(folder_id: str, permanent: bool = False) -> Dict[str, Any]:
    """Delete a folder (soft by default)."""

    if not folder_id:
        return error_response("/folders", 422, "folder_id is required")

    params: Dict[str, Any] = {}
    if permanent:
        params["permanent"] = "1"
    return await ajoplin.delete(f"/folders/{folder_id}", params)


# Resource Tools


@mcp.tool()
async def resources_list(
    fields: Optional[List[str]] = None,
    limit: Optional[Any] = None,
    cursor: Optional[str] = None,
) -> Dict[str, Any]:
    """List resources with pagination."""

    normalized_limit = ensure_limit("/resources", limit, config.max_limit)
    if isinstance(normalized_limit, dict) and normalized_limit.get("error"):
        return normalized_limit

    params = {
        "limit": normalized_limit,
        "page": decode_cursor(cursor),
        "fields": serialize_fields(fields, DEFAULT_RESOURCE_FIELDS),
    }

    response = await ajoplin.get("/resources", params)
    if "error" in response:
        return response

    items = response.get("items", [])
    has_more = response.get("has_more", False)
    return build_paginated_response(items, has_more, params["page"])


@mcp.tool()
async def resources_get(resource_id: str, fields: Optional[List[str]] = None) -> Dict[str, Any]:
    """Fetch resource metadata."""

    if not resource_id:
        return error_response("/resources", 422, "resource_id is required")

    params = {"fields": serialize_fields(fields, DEFAULT_RESOURCE_FIELDS)}
    return await ajoplin.get(f"/resources/{resource_id}", params)


@mcp.tool()
async def resources_download_file(resource_id: str, filename: Optional[str] = None) -> Dict[str, Any]:
    """Download a resource file to the configured download directory."""

    if not resource_id:
        return error_response("/resources", 422, "resource_id is required")

    meta = await ajoplin.get(f"/resources/{resource_id}")
    if "error" in meta:
        return meta

    base_name = filename or meta.get("filename") or meta.get("title") or resource_id
    final_name = f"{resource_id}-{os.path.basename(base_name)}"

    try:
        target_path = ensure_safe_path(config.download_dir, final_name)
    except ValueError as exc:
        return error_response(f"/resources/{resource_id}/file", 400, str(exc))

    download = await ajoplin.get(f"/resources/{resource_id}/file", expect_json=False)
    if "error" in download:
        return download

    try:
        with open(target_path, "wb") as handle:
            handle.write(download.get("content", b""))
    except OSError as exc:
        return error_response(f"/resources/{resource_id}/file", 500, f"Failed to write file: {exc}")

    return {"file_path": target_path}


@mcp.tool()
async def resources_upload(file_path: str, props: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Upload a local file as a Joplin resource."""

    if not file_path:
        return error_response("/resources", 422, "file_path is required")

    abs_path = os.path.abspath(file_path)
    if not os.path.isfile(abs_path):
        return error_response("/resources", 400, "file_path must reference an existing file")

    file_size = os.path.getsize(abs_path)
    if file_size > config.max_upload_bytes:
        return error_response("/resources", 413, "File exceeds maximum upload size")

    form_data: Dict[str, Any] = {}
    if props:
        form_data["props"] = json.dumps(props)

    content_type = mimetypes.guess_type(abs_path)[0] or "application/octet-stream"

    try:
        with open(abs_path, "rb") as handle:
            files = {"data": (os.path.basename(abs_path), handle, content_type)}
            response = await ajoplin.post_form("/resources", form_data=form_data, files=files)
    except OSError as exc:
        return error_response("/resources", 500, f"Failed to read file: {exc}")

    return response


# Search and Events


@mcp.tool()
async def search_query(
    query: str,
    search_type: Optional[Literal["note", "folder", "tag", "resource"]] = None,
    fields: Optional[List[str]] = None,
    limit: Optional[Any] = None,
    order_by: Optional[str] = None,
    order_dir: Optional[Literal["ASC", "DESC"]] = None,
    cursor: Optional[str] = None,
) -> Dict[str, Any]:
    """Execute a Joplin search query."""

    if not query or not query.strip():
        return error_response("/search", 422, "query is required")

    normalized_limit = ensure_limit("/search", limit, config.max_limit)
    if isinstance(normalized_limit, dict) and normalized_limit.get("error"):
        return normalized_limit

    params: Dict[str, Any] = {
        "query": query,
        "limit": normalized_limit,
        "page": decode_cursor(cursor),
        "fields": serialize_fields(fields, DEFAULT_NOTE_FIELDS),
    }

    if search_type:
        params["type"] = search_type
    if order_by:
        params["order_by"] = order_by
    if order_dir:
        params["order_dir"] = order_dir

    response = await ajoplin.get("/search", params)
    if "error" in response:
        return response

    items = response.get("items", [])
    has_more = response.get("has_more", False)
    paginated = build_paginated_response(items, has_more, params["page"])
    if response.get("cursor"):
        paginated["next_cursor"] = response["cursor"]
    return paginated


@mcp.tool()
async def events_tail(cursor: Optional[str] = None, limit: Optional[Any] = None) -> Dict[str, Any]:
    """Tail the Joplin events feed."""

    params: Dict[str, Any] = {}

    normalized_limit = ensure_limit("/events", limit, config.max_limit)
    if isinstance(normalized_limit, dict) and normalized_limit.get("error"):
        return normalized_limit
    params["limit"] = normalized_limit

    if cursor:
        params["cursor"] = cursor

    response = await ajoplin.get("/events", params)
    if "error" in response:
        return response

    items = response.get("items", [])
    result: Dict[str, Any] = {
        "items": items,
        "has_more": bool(response.get("has_more")) or bool(response.get("cursor")),
    }

    if response.get("cursor"):
        result["next_cursor"] = response["cursor"]

    return result


# Auth Tools


@mcp.tool()
async def joplin_auth_start() -> Dict[str, Any]:
    """Initiate the Joplin clipper auth flow."""

    if not config.enable_auth_flow:
        return error_response("/auth", 403, "Auth flow is disabled")

    return await ajoplin.post("/auth", {}, allow_missing_token=True)


@mcp.tool()
async def joplin_auth_check(auth_token: str) -> Dict[str, Any]:
    """Check the status of an auth token issued by the clipper auth flow."""

    if not config.enable_auth_flow:
        return error_response("/auth/check", 403, "Auth flow is disabled")

    if not auth_token or not auth_token.strip():
        return error_response("/auth/check", 422, "auth_token is required")

    params = {"auth_token": auth_token}
    return await ajoplin.get("/auth/check", params, allow_missing_token=True)


@mcp.tool()
async def joplin_ping() -> Dict[str, Any]:
    """Ping the Joplin server for health check (F64).

    Returns: { ok: boolean, server?: string }
    """
    # Allow ping without token (handled in Async client)
    resp = await ajoplin.get("/ping")
    if "error" in resp:
        return resp
    # Joplin returns a plain string sometimes; normalize
    if isinstance(resp, dict):
        return {"ok": True, **({"server": resp.get("name")} if "name" in resp else {})}
    # If response is text like "JoplinClipperServer"
    return {"ok": True, "server": str(resp)}


if __name__ == "__main__":
    mcp.run()
