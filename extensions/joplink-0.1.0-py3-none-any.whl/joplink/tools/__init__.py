"""
Joplink tools package.

Tool definitions are organized by category for maintainability.
All tools are registered with the FastMCP server instance.
"""
