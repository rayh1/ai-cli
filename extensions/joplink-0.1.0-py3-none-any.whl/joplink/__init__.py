"""
Joplink - MCP server for Joplin Data API
"""

__version__ = "0.1.0"